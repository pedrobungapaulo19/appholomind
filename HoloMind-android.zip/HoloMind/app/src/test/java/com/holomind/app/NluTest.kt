package com.holomind.app

import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class NluTest {
    private fun names(t: String) = Nlu.parse(t).map { it.name }

    @Test fun contactosDeVariasFormas() {
        for (f in listOf("contactos", "entra nos contactos", "abre contacto", "abre os contatos", "abrir contatos")) {
            val r = Nlu.parse(f)
            assertEquals(f, 1, r.size)
            assertEquals("OPEN", r[0].name)
            assertEquals("contacts", r[0].arg)
        }
    }

    @Test fun pedidosEncadeados() {
        val r = Nlu.parse("entra nos contactos e liga para o fulano")
        assertEquals(listOf("OPEN", "CALL"), r.map { it.name })
        assertEquals("fulano", r[1].arg)
        assertEquals(listOf("OPEN", "CALL"), names("entra nos contactos liga para o fulano"))
        assertEquals(listOf("OPEN", "READ"), names("entra nas mensagens ler mensagens"))
        assertEquals(listOf("READ", "REPLY"), names("lê as mensagens e responde à maria dizendo já vou"))
    }

    @Test fun palavraDeAtivacaoNaMesmaFrase() {
        assertEquals(listOf("READ"), names("olo mente ler mensagem"))
        assertEquals(listOf("TIME"), names("olo que horas são"))
        assertTrue(names("olo mente").isEmpty())
        assertTrue(names("olá mundo").isEmpty())
    }

    @Test fun verificarMensagensDaBarra() {
        assertEquals(listOf("READ"), names("olo verifica as mensagens me fala quais são as mensagens que estão na barra de notificação"))
        assertEquals(listOf("READ"), names("notificações"))
    }

    @Test fun entrarNaMensagemEResponder() {
        val r = Nlu.parse("olo entra na mensagem x responde a mensagem x")
        assertEquals(listOf("CHAT", "REPLY"), r.map { it.name })
        assertEquals("x", r[0].arg)
        assertEquals("x", r[1].arg)
    }

    @Test fun horaSoComUmaPalavra() {
        assertEquals(listOf("TIME"), names("hora"))
        assertEquals(listOf("TIME"), names("me diz que horas são"))
        assertEquals(listOf("TIME"), names("me ajuda a saber que horas são"))
        assertEquals(listOf("HELP"), names("ajuda"))
    }

    @Test fun enviarEResponderComTexto() {
        val s = Nlu.parse("manda mensagem ao joão dizendo olá")[0]
        assertEquals("SEND", s.name); assertEquals("joao", s.arg); assertEquals("ola", s.body); assertEquals("wa", s.channel)
        val sms = Nlu.parse("manda sms para a maria dizendo chego já")[0]
        assertEquals("sms", sms.channel); assertEquals("maria", sms.arg)
        val r = Nlu.parse("responde ao joão dizendo ok")[0]
        assertEquals("REPLY", r.name); assertEquals("joao", r.arg); assertEquals("ok", r.body)
    }

    @Test fun mensagemNaoECorrigidaDepoisDeDizendo() {
        val c = Nlu.parse("liga para o joão e depois manda mensagem ao joão dizendo estou a chegar")
        assertEquals(listOf("CALL", "SEND"), c.map { it.name })
        assertEquals("estou a chegar", c[1].body)
    }

    @Test fun ingles() {
        assertEquals(listOf("TIME"), names("what time is it"))
        assertEquals("app:facebook", Nlu.parse("open facebook")[0].arg)
        assertEquals("john", Nlu.parse("call john")[0].arg)
        assertEquals(listOf("READ"), names("read my messages"))
    }

    @Test fun notasELembretes() {
        assertEquals(listOf("REMIND"), names("lembra-me de ligar ao joão daqui a dez minutos"))
        assertEquals(listOf("NOTE_READ"), names("ler notas"))
        assertEquals(listOf("NOTE_ADD"), names("anota comprar pão"))
    }

    @Test fun lanternaEVolume() {
        assertEquals(listOf("FLASH_ON"), names("ligar a lanterna"))
        assertEquals(listOf("FLASH_OFF"), names("apaga a lanterna"))
        assertEquals(listOf("VOLUME_UP"), names("aumenta o volume"))
        assertEquals(listOf("VOLUME_DOWN"), names("baixa o volume"))
    }
}
