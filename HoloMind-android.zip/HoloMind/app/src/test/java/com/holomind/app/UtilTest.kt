package com.holomind.app

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class UtilTest {
    private val words = listOf("holomind", "holo mind", "olo mind")

    @Test fun normRemoveAcentosEEspacos() = assertEquals("joao", Util.norm("  João "))

    @Test fun reconheceVariantes() {
        assertTrue(Util.matches("olo mind", words))
        assertTrue(Util.matches("ei holo mind estás aí", words))
    }

    @Test fun toleraUmaLetraTrocada() {
        assertTrue(Util.matches("holomaind", words))
        assertTrue(Util.matches("olomind", words))
    }

    @Test fun naoAtivaComOutraFrase() {
        assertFalse(Util.matches("bom dia a todos", words))
        assertFalse(Util.matches("ola mundo", words))
        assertFalse(Util.matches("", words))
    }

    @Test fun rmsDeSilencioEZero() = assertEquals(0.0, Util.rms(ShortArray(100), 100), 0.0001)
}
