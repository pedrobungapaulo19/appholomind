package com.holomind.app

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test
import java.util.Calendar

class UtilTest {
    private val words = Prefs.DEFAULT_WAKE.split(",").map { Util.norm(it) }
    private val holo = Prefs.WAKE_HOLO.split(",").map { Util.norm(it) }

    @Test fun normRemoveAcentosEEspacos() = assertEquals("joao", Util.norm("  João "))

    @Test fun reconheceVariantes() {
        assertTrue(Util.isWake("olo mind", words))
        assertTrue(Util.isWake("ei holo mind estás aí", words))
    }

    @Test fun toleraPronunciaPortuguesa() {
        assertTrue(Util.isWake("holomaind", words))
        assertTrue(Util.isWake("olo mente", words))
        assertTrue(Util.isWake("rolo mente", words))
        assertTrue(Util.isWake("olo main", words))
    }

    @Test fun naoAtivaComOutraFrase() {
        assertFalse(Util.isWake("bom dia a todos", words))
        assertFalse(Util.isWake("ola mundo", words))
        assertFalse(Util.isWake("alo mundo", words))
        assertFalse(Util.isWake("a lente", words))
        assertFalse(Util.isWake("um momento", words))
        assertFalse(Util.isWake("", words))
    }

    @Test fun palavraCurtaHolo() {
        assertTrue(Util.isWake("holo", holo))
        assertTrue(Util.isWake("olo", holo))
        assertFalse(Util.isWake("colocar o bolo na mesa", holo))
        assertFalse(Util.isWake("bolo", holo))
    }

    @Test fun palavrasComunsNaoAtivam() {
        assertTrue(Util.isCommon("olá"))
        assertTrue(Util.isCommon("mãe"))
        assertTrue(Util.isCommon("ola mae"))
        assertFalse(Util.isCommon("olo mente"))
        assertFalse(Util.isCommon("holo"))
    }

    @Test fun detetaIngles() {
        assertTrue(Util.looksEnglish("hello how are you"))
        assertTrue(Util.looksEnglish("open the app"))
        assertFalse(Util.looksEnglish("mensagem de joao"))
        assertFalse(Util.looksEnglish("ligar para o joao"))
    }

    @Test fun nomesDeAppsDitosAPortuguesa() {
        assertEquals(Util.skelApp("whatsapp"), Util.skelApp("uatsapp"))
        assertEquals(Util.skelApp("instagram"), Util.skelApp("insta gram"))
    }

    @Test fun esqueletoFonetico() {
        assertEquals(Util.skeleton("holomind"), Util.skeleton("olo mente"))
    }

    @Test fun rmsDeSilencioEZero() = assertEquals(0.0, Util.rms(ShortArray(100), 100), 0.0001)

    private fun now(h: Int, m: Int): Long {
        val c = Calendar.getInstance()
        c.set(2026, Calendar.NOVEMBER, 19, h, m, 0)
        c.set(Calendar.MILLISECOND, 0)
        return c.timeInMillis
    }

    @Test fun lembreteDaquiAMinutos() {
        val n = now(10, 0)
        val r = Reminders.parse("lembra me de ligar ao joao daqui a dez minutos", n)
        assertNotNull(r)
        assertEquals("ligar ao joao", r!!.first)
        assertEquals(n + 10 * 60_000L, r.second)
    }

    @Test fun lembreteMeiaHora() {
        val n = now(10, 0)
        val r = Reminders.parse("lembra me de comprar pao daqui a meia hora", n)!!
        assertEquals("comprar pao", r.first)
        assertEquals(n + 30 * 60_000L, r.second)
    }

    @Test fun lembreteHoraDaNoite() {
        val n = now(10, 0)
        val r = Reminders.parse("lembra me de tomar o remedio as oito horas da noite", n)!!
        assertEquals("tomar o remedio", r.first)
        assertEquals(now(20, 0), r.second)
    }

    @Test fun lembreteEMeia() {
        val n = now(10, 0)
        val r = Reminders.parse("lembra me da reuniao as tres e meia", n)!!
        assertEquals(now(15, 30), r.second)
    }

    @Test fun lembreteSemHora() = assertNull(Reminders.parse("lembra me de ligar", now(10, 0)))
}
