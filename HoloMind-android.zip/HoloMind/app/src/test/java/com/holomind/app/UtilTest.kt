package com.holomind.app

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class UtilTest {
    private val words = Prefs.DEFAULT_WAKE.split(",").map { Util.norm(it) }

    @Test fun normRemoveAcentosEEspacos() = assertEquals("joao", Util.norm("  João "))

    @Test fun reconheceVariantes() {
        assertTrue(Util.isWake("olo mind", words))
        assertTrue(Util.isWake("ei holo mind estás aí", words))
    }

    @Test fun toleraPronunciaPortuguesa() {
        assertTrue(Util.isWake("holomaind", words))
        assertTrue(Util.isWake("olo mente", words))
        assertTrue(Util.isWake("rolo mente", words))
        assertTrue(Util.isWake("olo main", words))
    }

    @Test fun naoAtivaComOutraFrase() {
        assertFalse(Util.isWake("bom dia a todos", words))
        assertFalse(Util.isWake("ola mundo", words))
        assertFalse(Util.isWake("um momento", words))
        assertFalse(Util.isWake("ola mundo", words))
        assertFalse(Util.isWake("alo mundo", words))
        assertFalse(Util.isWake("a lente", words))
        assertFalse(Util.isWake("", words))
    }

    @Test fun esqueletoFonetico() {
        assertEquals(Util.skeleton("holomind"), Util.skeleton("olo mente"))
    }

    @Test fun rmsDeSilencioEZero() = assertEquals(0.0, Util.rms(ShortArray(100), 100), 0.0001)
}
