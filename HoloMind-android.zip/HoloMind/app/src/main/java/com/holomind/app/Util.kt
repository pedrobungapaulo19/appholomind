package com.holomind.app

import java.text.Normalizer
import kotlin.math.sqrt

object Util {
    private val accents = Regex("\\p{InCombiningDiacriticalMarks}+")

    fun norm(s: String): String =
        Normalizer.normalize(s, Normalizer.Form.NFD).replace(accents, "").lowercase().trim()

    /** Compara o texto ouvido com as palavras de ativação, tolerando 1–2 letras trocadas. */
    fun matches(text: String, words: List<String>): Boolean {
        val t = norm(text)
        if (t.isEmpty()) return false
        val flat = t.replace(" ", "")
        return words.any { w -> t.contains(w) || fuzzyContains(flat, w.replace(" ", "")) }
    }

    private fun fuzzyContains(h: String, n: String): Boolean {
        if (n.length < 6) return h.contains(n)
        val maxD = if (n.length >= 9) 2 else 1
        for (len in (n.length - maxD)..(n.length + maxD)) {
            if (len > h.length) continue
            for (i in 0..(h.length - len)) if (lev(h.substring(i, i + len), n) <= maxD) return true
        }
        return false
    }

    private fun lev(a: String, b: String): Int {
        var prev = IntArray(b.length + 1) { it }
        for (i in 1..a.length) {
            val cur = IntArray(b.length + 1)
            cur[0] = i
            for (j in 1..b.length) {
                cur[j] = minOf(prev[j] + 1, cur[j - 1] + 1, prev[j - 1] + if (a[i - 1] == b[j - 1]) 0 else 1)
            }
            prev = cur
        }
        return prev[b.length]
    }

    fun rms(buf: ShortArray, n: Int): Double {
        var sum = 0.0
        for (i in 0 until n) sum += buf[i].toDouble() * buf[i]
        return sqrt(sum / n)
    }
}
