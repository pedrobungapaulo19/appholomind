package com.holomind.app

import java.text.Normalizer
import kotlin.math.sqrt

object Util {
    private val accents = Regex("\\p{InCombiningDiacriticalMarks}+")

    fun norm(s: String): String =
        Normalizer.normalize(s, Normalizer.Form.NFD).replace(accents, "").lowercase().trim()

    /** Compara o texto ouvido com as palavras de ativação, tolerando 1–2 letras trocadas. */
    fun matches(text: String, words: List<String>): Boolean {
        val t = norm(text)
        if (t.isEmpty()) return false
        val tokens = t.split(" ").filter { it.isNotEmpty() }
        val flat = t.replace(" ", "")
        return words.any { w ->
            if (w.length < 6 && !w.contains(' ')) {
                // palavras curtas (ex.: "holo"): só inteiras e em frases curtas, para não ativar com "colocar"
                tokens.size <= 2 && tokens.contains(w)
            } else {
                t.contains(w) || fuzzyContains(flat, w.replace(" ", ""))
            }
        }
    }

    /**
     * Palavra de ativação "à portuguesa": o reconhecedor ouve "holomaind" como "olo mente", "olho mente",
     * "hollow mine"… Comparamos o esqueleto fonético (sem vogais a/e/i/o e h, d≈t, b≈p…) em frases curtas.
     */
    fun isWake(text: String, words: List<String>): Boolean {
        if (matches(text, words)) return true
        val t = norm(text)
        if (t.isEmpty() || t.split(" ").size > 3) return false
        val ts = skeleton(t)
        return words.any { w ->
            val ws = skeleton(w)
            ws.length >= 3 && ts.contains(ws)
        }
    }

    fun skeleton(s: String): String {
        val t = norm(s).replace(Regex("[^a-z]"), "")
        val sb = StringBuilder()
        for (ch in t) {
            if (ch in "aeiohyw") continue
            val c = when (ch) {
                'd' -> 't'; 'b' -> 'p'; 'v' -> 'f'; 'z' -> 's'; 'g' -> 'k'; 'c' -> 'k'; 'q' -> 'k'
                else -> ch
            }
            if (sb.isEmpty() || sb[sb.length - 1] != c) sb.append(c)
        }
        return sb.toString()
    }

    private fun fuzzyContains(h: String, n: String): Boolean {
        if (n.length < 6) return h.contains(n)
        val maxD = if (n.length >= 9) 2 else 1
        for (len in (n.length - maxD)..(n.length + maxD)) {
            if (len > h.length) continue
            for (i in 0..(h.length - len)) if (lev(h.substring(i, i + len), n) <= maxD) return true
        }
        return false
    }

    private fun lev(a: String, b: String): Int {
        var prev = IntArray(b.length + 1) { it }
        for (i in 1..a.length) {
            val cur = IntArray(b.length + 1)
            cur[0] = i
            for (j in 1..b.length) {
                cur[j] = minOf(prev[j] + 1, cur[j - 1] + 1, prev[j - 1] + if (a[i - 1] == b[j - 1]) 0 else 1)
            }
            prev = cur
        }
        return prev[b.length]
    }

    private val common = setOf(
        "ola", "mae", "de", "do", "da", "o", "a", "e", "um", "uma", "que", "sim", "nao", "ai", "eh", "ah", "oh",
        "ja", "la", "ali", "aqui", "bom", "boa", "dia", "tudo", "bem", "mais", "para", "pra", "com", "sem", "ele",
        "ela", "eu", "tu", "me", "te", "se", "ver", "vou", "ok", "hum", "oi", "alo", "ou", "os", "as", "no", "na",
        "em", "por", "foi", "era", "ser", "tem", "ter", "mas", "meu", "seu", "nos", "pai", "mano", "amor"
    )

    /** Palavras comuns que nunca devem servir de palavra de ativação (evita ativar com "olá" ou "mãe"). */
    fun isCommon(w: String): Boolean {
        val t = norm(w)
        val tokens = t.split(" ").filter { it.isNotEmpty() }
        return tokens.isEmpty() || t.replace(" ", "").length < 3 || tokens.all { it in common }
    }

    private val enWords = setOf(
        "the", "and", "you", "is", "are", "it", "my", "your", "hello", "hi", "how", "what", "where", "when",
        "please", "thanks", "thank", "can", "will", "not", "this", "that", "with", "for", "have", "does", "did",
        "hey", "good", "morning", "night", "see", "we", "they", "she", "he", "just", "from", "but", "yes", "to",
        "of", "open", "call", "send", "message", "messages", "read", "time", "today", "tomorrow", "i", "am"
    )
    private val ptWords = setOf(
        "o", "a", "os", "as", "de", "do", "da", "que", "e", "um", "uma", "para", "com", "nao", "sim", "eu", "tu",
        "voce", "obrigado", "obrigada", "ola", "bom", "boa", "tudo", "bem", "por", "mais", "mas", "se", "em", "no",
        "na", "foi", "vai", "estou", "esta", "tem", "mensagem", "ligar", "abrir", "meu", "minha", "dia", "noite"
    )

    /** Heurística simples: o texto parece inglês? (para escolher a voz e o idioma ao ler) */
    fun looksEnglish(text: String): Boolean {
        val tokens = norm(text).replace(Regex("[^a-z ]"), " ").split(" ").filter { it.isNotEmpty() }
        if (tokens.isEmpty()) return false
        val en = tokens.count { it in enWords }
        val pt = tokens.count { it in ptWords }
        return en > pt
    }

    /** Esqueleto para nomes de apps ditos à portuguesa ("uatsapp" ~ "whatsapp"): ignora todas as vogais. */
    fun skelApp(s: String): String {
        val t = norm(s).replace(Regex("[^a-z]"), "")
        val sb = StringBuilder()
        for (ch in t) {
            if (ch in "aeiouhyw") continue
            val c = when (ch) {
                'd' -> 't'; 'b' -> 'p'; 'v' -> 'f'; 'z' -> 's'; 'g' -> 'k'; 'c' -> 'k'; 'q' -> 'k'
                else -> ch
            }
            if (sb.isEmpty() || sb[sb.length - 1] != c) sb.append(c)
        }
        return sb.toString()
    }

    fun levenshtein(a: String, b: String): Int = lev(a, b)

    fun rms(buf: ShortArray, n: Int): Double {
        var sum = 0.0
        for (i in 0 until n) sum += buf[i].toDouble() * buf[i]
        return sqrt(sum / n)
    }
}
