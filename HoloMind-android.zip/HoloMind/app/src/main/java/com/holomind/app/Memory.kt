package com.holomind.app

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.util.Calendar
import java.util.Collections

/**
 * Memória local do HoloMind (nada sai do telemóvel): apelidos de contactos, frases aprendidas,
 * horas de uso, contactos prioritários e notas/lembretes.
 */
object Memory {
    /** Contexto de curto prazo (só em RAM): com quem se falou por último. */
    @Volatile var lastContact: String? = null
    val readSenders: MutableSet<String> = Collections.synchronizedSet(mutableSetOf<String>())

    private fun sp(ctx: Context) = ctx.getSharedPreferences("holomind_mem", Context.MODE_PRIVATE)

    private fun obj(ctx: Context, k: String): JSONObject =
        try { JSONObject(sp(ctx).getString(k, "{}") ?: "{}") } catch (e: Exception) { JSONObject() }

    private fun arr(ctx: Context, k: String): JSONArray =
        try { JSONArray(sp(ctx).getString(k, "[]") ?: "[]") } catch (e: Exception) { JSONArray() }

    private fun save(ctx: Context, k: String, v: Any) { sp(ctx).edit().putString(k, v.toString()).apply() }

    // ---- apelidos ("o mano" -> "João Silva")
    fun aliasOf(ctx: Context, alias: String): String? =
        obj(ctx, "aliases").optString(Util.norm(alias), "").ifBlank { null }

    fun setAlias(ctx: Context, alias: String, contact: String) {
        val o = obj(ctx, "aliases"); o.put(Util.norm(alias), contact); save(ctx, "aliases", o)
    }

    // ---- frases aprendidas ("apaga a luz" -> "lanterna_off")
    fun customAction(ctx: Context, phrase: String): String? =
        obj(ctx, "custom").optString(phrase, "").ifBlank { null }

    fun setCustom(ctx: Context, phrase: String, action: String) {
        val o = obj(ctx, "custom"); o.put(phrase, action); save(ctx, "custom", o)
    }

    // ---- horas de uso
    fun recordUse(ctx: Context) {
        val a = arr(ctx, "hours")
        val h = Calendar.getInstance().get(Calendar.HOUR_OF_DAY)
        for (i in 0 until 24) if (a.optInt(i, -1) < 0) a.put(i, 0)
        a.put(h, a.optInt(h, 0) + 1)
        save(ctx, "hours", a)
    }

    fun hours(ctx: Context): IntArray {
        val a = arr(ctx, "hours")
        return IntArray(24) { a.optInt(it, 0) }
    }

    /** Sugere um horário de silêncio: a maior sequência de horas (>= 5) em que quase nunca é usado. */
    fun suggestQuiet(ctx: Context): IntArray? {
        val h = hours(ctx)
        val total = h.sum()
        if (total < 20) return null
        val lim = total / 50
        var bestLen = 0
        var bestStart = 0
        for (s in 0 until 24) {
            var len = 0
            while (len < 24 && h[(s + len) % 24] <= lim) len++
            if (len > bestLen) { bestLen = len; bestStart = s }
        }
        if (bestLen < 5 || bestLen >= 24) return null
        return intArrayOf(bestStart, (bestStart + bestLen) % 24)
    }

    // ---- contactos prioritários (a quem responde)
    fun bumpPriority(ctx: Context, sender: String) {
        val o = obj(ctx, "prio"); o.put(sender, o.optInt(sender, 0) + 1); save(ctx, "prio", o)
    }

    fun priorityScore(ctx: Context, sender: String): Int = obj(ctx, "prio").optInt(sender, 0)

    fun topPriority(ctx: Context, n: Int): List<String> {
        val o = obj(ctx, "prio")
        val l = ArrayList<Pair<String, Int>>()
        val keys = o.keys()
        while (keys.hasNext()) { val k = keys.next(); l.add(k to o.optInt(k, 0)) }
        return l.sortedByDescending { it.second }.take(n).map { it.first }
    }

    // ---- notas e lembretes (at = 0 -> nota simples; at > 0 -> lembrete)
    fun addNote(ctx: Context, text: String, at: Long) {
        val a = arr(ctx, "notes")
        a.put(JSONObject().put("t", text).put("at", at))
        val out = JSONArray()
        val from = if (a.length() > 60) a.length() - 60 else 0
        for (i in from until a.length()) out.put(a.get(i))
        save(ctx, "notes", out)
    }

    fun notes(ctx: Context): List<Pair<String, Long>> {
        val a = arr(ctx, "notes")
        val l = ArrayList<Pair<String, Long>>()
        for (i in 0 until a.length()) {
            val o = a.optJSONObject(i) ?: continue
            l.add(o.optString("t", "") to o.optLong("at", 0L))
        }
        return l
    }

    fun clearNotes(ctx: Context) { save(ctx, "notes", JSONArray()) }

    /** Devolve (e remove) os lembretes cuja hora já passou. */
    fun popDue(ctx: Context, now: Long): List<String> {
        val a = arr(ctx, "notes")
        val keep = JSONArray()
        val due = ArrayList<String>()
        for (i in 0 until a.length()) {
            val o = a.optJSONObject(i) ?: continue
            val at = o.optLong("at", 0L)
            if (at in 1..now) due.add(o.optString("t", "")) else keep.put(o)
        }
        if (due.isNotEmpty()) save(ctx, "notes", keep)
        return due
    }

    /** Hora do próximo lembrete (0 = nenhum). */
    fun nextDue(ctx: Context): Long {
        var best = 0L
        for ((_, at) in notes(ctx)) if (at > 0 && (best == 0L || at < best)) best = at
        return best
    }

    // ---- resumo para o ecrã "O que aprendi"
    fun snapshot(ctx: Context): JSONObject {
        val h = hours(ctx)
        val hs = JSONArray(); for (x in h) hs.put(x)
        val prio = JSONArray(); for (p in topPriority(ctx, 5)) prio.put(p)
        val sug = suggestQuiet(ctx)
        val o = JSONObject()
            .put("hours", hs).put("uses", h.sum())
            .put("aliases", obj(ctx, "aliases")).put("custom", obj(ctx, "custom"))
            .put("priority", prio).put("notes", notes(ctx).size)
        if (sug != null) o.put("suggest", JSONArray().put(sug[0]).put(sug[1]))
        return o
    }

    fun forgetAll(ctx: Context) {
        sp(ctx).edit().clear().apply()
        lastContact = null
        readSenders.clear()
    }
}
