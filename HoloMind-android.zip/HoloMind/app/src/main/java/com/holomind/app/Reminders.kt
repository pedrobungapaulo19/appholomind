package com.holomind.app

import java.util.Calendar

/** Interpreta "lembra-me de X daqui a dez minutos / às cinco e meia da tarde" (sem dependências do Android). */
object Reminders {
    private val units = mapOf(
        "zero" to 0, "um" to 1, "uma" to 1, "dois" to 2, "duas" to 2, "tres" to 3, "quatro" to 4, "cinco" to 5,
        "seis" to 6, "sete" to 7, "oito" to 8, "nove" to 9, "dez" to 10, "onze" to 11, "doze" to 12,
        "treze" to 13, "catorze" to 14, "quatorze" to 14, "quinze" to 15, "dezasseis" to 16, "dezesseis" to 16,
        "dezassete" to 17, "dezessete" to 17, "dezoito" to 18, "dezanove" to 19, "dezenove" to 19
    )
    private val tens = mapOf("vinte" to 20, "trinta" to 30, "quarenta" to 40, "cinquenta" to 50)
    private val filler = setOf("lembra", "me", "de", "da", "do", "que", "lembrete", "avisa", "a", "para", "um")

    /** Lê um número por extenso a partir de w[i]; devolve (valor, nº de palavras) ou null. */
    fun parseNumber(w: List<String>, i: Int): Pair<Int, Int>? {
        if (i >= w.size) return null
        val digits = w[i].toIntOrNull()
        if (digits != null) return digits to 1
        val tv = tens[w[i]]
        if (tv != null) {
            if (i + 2 < w.size && w[i + 1] == "e") {
                val u = units[w[i + 2]]
                if (u != null && u in 1..9) return (tv + u) to 3
            }
            return tv to 1
        }
        val u = units[w[i]] ?: return null
        return u to 1
    }

    /** t já normalizado (sem acentos, minúsculas). Devolve (texto do lembrete, hora em millis) ou null. */
    fun parse(t: String, now: Long): Pair<String, Long>? {
        val w = t.split(" ").filter { it.isNotBlank() }
        var at = -1L
        var cutFrom = -1
        var cutTo = -1

        // "daqui a N minutos/horas", "daqui a meia hora"
        val di = w.indexOf("daqui")
        if (di >= 0 && di + 2 < w.size && w[di + 1] == "a") {
            val i = di + 2
            var minutes = -1
            if (w[i] == "meia" && i + 1 < w.size && w[i + 1].startsWith("hora")) {
                minutes = 30; cutTo = i + 2
            } else {
                val n = parseNumber(w, i)
                if (n != null && i + n.second < w.size) {
                    val u = w[i + n.second]
                    if (u.startsWith("minuto")) { minutes = n.first; cutTo = i + n.second + 1 }
                    else if (u.startsWith("hora")) { minutes = n.first * 60; cutTo = i + n.second + 1 }
                }
            }
            if (minutes > 0) { at = now + minutes * 60_000L; cutFrom = di }
        }

        // "as 5 [horas] [e meia | e um quarto | e 20] [da manha/tarde/noite]"
        if (at < 0) {
            for (ai in w.indices) {
                val isAs = w[ai] == "as" || (w[ai] == "a" && ai + 1 < w.size && (w[ai + 1] == "uma" || w[ai + 1] == "um"))
                if (!isAs) continue
                val n = parseNumber(w, ai + 1) ?: continue
                var h = n.first
                var m = 0
                var j = ai + 1 + n.second
                if (j < w.size && w[j].startsWith("hora")) j++
                if (j < w.size && w[j] == "e") {
                    if (j + 1 < w.size && w[j + 1] == "meia") { m = 30; j += 2 }
                    else if (j + 2 < w.size && w[j + 1] == "um" && w[j + 2] == "quarto") { m = 15; j += 3 }
                    else {
                        val n2 = parseNumber(w, j + 1)
                        if (n2 != null) { m = n2.first; j += 1 + n2.second }
                    }
                }
                var explicit = false
                var pm = false
                if (j + 1 < w.size && w[j] == "da") {
                    when (w[j + 1]) {
                        "tarde", "noite" -> { pm = true; explicit = true; j += 2 }
                        "manha", "madrugada" -> { explicit = true; j += 2 }
                    }
                }
                if (h > 23 || m > 59) continue
                if (pm && h < 12) h += 12
                val cal = Calendar.getInstance()
                cal.timeInMillis = now
                cal.set(Calendar.HOUR_OF_DAY, h)
                cal.set(Calendar.MINUTE, m)
                cal.set(Calendar.SECOND, 0)
                cal.set(Calendar.MILLISECOND, 0)
                var t1 = cal.timeInMillis
                if (!explicit && h in 1..11) {
                    // sem "manhã/tarde/noite": a ocorrência mais próxima no futuro
                    val t2 = t1 + 12 * 3_600_000L
                    t1 = if (t1 > now) t1 else if (t2 > now) t2 else t1 + 24 * 3_600_000L
                } else if (t1 <= now) {
                    t1 += 24 * 3_600_000L
                }
                at = t1; cutFrom = ai; cutTo = j
                break
            }
        }
        if (at < 0) return null

        val words = ArrayList<String>()
        for (k in w.indices) if (k < cutFrom || k >= cutTo) words.add(w[k])
        while (words.isNotEmpty() && words[0] in filler) words.removeAt(0)
        val body = words.joinToString(" ").ifBlank { "lembrete" }
        return body to at
    }
}
