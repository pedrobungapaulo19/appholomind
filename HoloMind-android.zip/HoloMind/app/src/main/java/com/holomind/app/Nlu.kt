package com.holomind.app

/**
 * Interpretador de pedidos (offline, sem IA): percebe frases soltas e variadas em português e inglês,
 * tolera palavras a mais/menos e separa pedidos encadeados ("entra nos contactos e liga para o fulano").
 */
object Nlu {
    data class Cmd(
        val name: String,
        val arg: String = "",
        val body: String = "",
        val channel: String = "",
        val last: Boolean = false,
        val raw: String = ""
    )

    private val openV = setOf("abre", "abrir", "abra", "entra", "entrar", "entre", "vai", "ir", "va", "mostra", "mostrar", "acede", "aceder", "inicia", "open", "go", "launch")
    private val readV = setOf("le", "ler", "leia", "verifica", "verificar", "verifique", "ve", "ver", "veja", "consulta", "checa", "checar", "diz", "dizer", "fala", "falar", "mostra", "read", "check", "tell")
    private val callV = setOf("liga", "ligar", "ligue", "telefona", "telefonar", "chama", "chamar", "call", "phone", "contacta")
    private val replyV = setOf("responde", "responder", "responda", "reply")
    private val sendV = setOf("manda", "mandar", "mande", "envia", "enviar", "envie", "escreve", "escrever", "send")
    private val startV: Set<String> =
        (openV + callV + replyV + sendV + setOf("le", "ler", "leia", "verifica", "verificar", "verifique", "anota", "lembra")) -
            setOf("vai", "ir", "va", "go", "mostra", "mostrar")
    private val msgN = setOf("mensagem", "mensagens", "msg", "sms", "recado", "recados", "notificacao", "notificacoes", "mensagen", "mensages", "messages", "message")
    private val contN = setOf("contacto", "contactos", "contato", "contatos", "agenda")
    private val timeW = setOf("hora", "horas")
    private val batW = setOf("bateria", "carga", "battery")
    private val flashW = setOf("lanterna", "flashlight", "torch")
    private val upW = setOf("aumenta", "aumentar", "sobe", "subir", "mais", "alto", "up", "louder")
    private val downW = setOf("baixa", "baixar", "diminui", "diminuir", "menos", "down", "quieter")
    private val offW = setOf("apaga", "apagar", "desliga", "desligar", "fecha", "off")
    private val articles = setOf(
        "o", "a", "os", "as", "um", "uma", "no", "na", "nos", "nas", "ao", "aos", "do", "da", "dos", "das", "de", "em",
        "para", "pra", "pro", "app", "aplicativo", "aplicacao", "aplicacoes", "the", "my", "to", "from", "por", "favor",
        "me", "mim", "com"
    )
    private val cut = setOf("dizendo", "saying", "escrevendo", "no", "na", "pelo", "pela", "por", "via", "on", "by", "e", "depois")
    private val stopName: Set<String> =
        startV + openV + readV + setOf(
            "me", "fala", "diz", "quais", "que", "sao", "esta", "estao", "tem", "tenho", "novas", "novos", "recentes",
            "barra", "status", "notificacao", "notificacoes", "ai", "la", "aqui", "pra", "mim", "todas", "todos", "favor"
        )
    private val appBare = setOf(
        "whatsapp", "zap", "facebook", "instagram", "youtube", "telegram", "tiktok", "chrome", "camara", "camera",
        "galeria", "mapas", "definicoes", "agenda", "contactos", "contatos", "contacto", "contato", "messenger", "spotify", "gmail"
    )
    private val channelWords = setOf("sms", "whatsapp", "zap", "facebook", "messenger")
    private val bodyMarks = listOf("dizendo", "saying", "escrevendo")
    private val joiners = setOf("e", "depois", "entao", "seguida")
    private val lastWords = setOf("lhe", "ele", "ela", "him", "her")

    private val lex: Set<String> =
        (openV + readV + callV + replyV + sendV + msgN + contN + batW + flashW).filter { it.length >= 6 }.toSet()

    private fun hit(s: Set<String>, w: Set<String>) = w.any { it in s }

    /** Corrige erros pequenos do reconhecedor ("mensagen" -> "mensagem", "contatos" -> "contactos"). */
    private fun canon(t: String): String {
        if (t.length < 6 || t in lex) return t
        for (w in lex) {
            if (w[0] == t[0] && Math.abs(w.length - t.length) <= 1 && Util.levenshtein(w, t) <= 1) return w
        }
        return t
    }

    private fun clean(text: String): String =
        Util.norm(text).replace('-', ' ').replace(Regex("[^a-z0-9' ]"), " ").split(" ").filter { it.isNotEmpty() }.joinToString(" ")

    private fun nameAfter(c: List<String>, start: Int): String {
        var i = start
        while (i < c.size && (c[i] in articles || c[i] in msgN)) i++
        if (i >= c.size || c[i] in stopName) return ""
        val out = ArrayList<String>()
        while (i < c.size && c[i] !in cut && c[i] !in stopName) { out.add(c[i]); i++ }
        return out.joinToString(" ")
    }

    private fun bodyAfter(c: List<String>): String {
        for (k in bodyMarks) {
            val i = c.indexOf(k)
            if (i >= 0) {
                var rest = c.drop(i + 1)
                if (rest.isNotEmpty() && rest[0] == "que") rest = rest.drop(1)
                return rest.joinToString(" ")
            }
        }
        return ""
    }

    private fun firstIdx(c: List<String>, s: Set<String>): Int = c.indexOfFirst { it in s }

    /** Separa pedidos encadeados: "entra nos contactos e liga para o fulano" -> 2 pedidos. */
    private fun splitClauses(tokens: List<String>): List<List<String>> {
        val clauses = ArrayList<List<String>>()
        var cur = ArrayList<String>()
        for (t in tokens) {
            if (t in startV && cur.isNotEmpty()) {
                val prev = cur[cur.size - 1]
                val has = cur.any { it in startV }
                if (prev in joiners || (has && cur.size >= 2)) {
                    while (cur.isNotEmpty() && cur[cur.size - 1] in joiners) cur.removeAt(cur.size - 1)
                    clauses.add(cur)
                    cur = ArrayList()
                }
            }
            cur.add(t)
        }
        if (cur.isNotEmpty()) clauses.add(cur)
        return clauses
    }

    private fun clauseCmd(c: List<String>): Cmd? {
        val s = c.toSet()
        if (firstIdx(c, setOf("bom", "boa", "good")) >= 0 &&
            hit(s, setOf("dia", "tarde", "noite", "morning", "afternoon", "evening")) && c.size <= 4) return Cmd("ROUTINE")
        if (hit(s, setOf("obrigado", "obrigada", "cancelar", "esquece", "deixa", "thanks", "thank"))) return Cmd("FIM")
        if (hit(s, timeW) || ("time" in s && "what" in s)) return Cmd("TIME")
        if ("data" in s || ("dia" in s && hit(s, setOf("que", "hoje"))) || ("day" in s && "what" in s)) return Cmd("DATE")
        if (hit(s, batW)) return Cmd("BATTERY")
        if (hit(s, flashW)) return if (hit(s, offW)) Cmd("FLASH_OFF") else Cmd("FLASH_ON")
        if ("volume" in s || "louder" in s || "quieter" in s) {
            if (hit(s, upW)) return Cmd("VOLUME_UP")
            if (hit(s, downW)) return Cmd("VOLUME_DOWN")
        }
        if (hit(s, setOf("proxima", "proximo", "seguinte", "outra", "outro", "next")) &&
            (hit(s, msgN) || "outra" in s || "next" in s) && !hit(s, callV)) return Cmd("NEXT")

        var v = firstIdx(c, sendV)
        if (v >= 0 && (hit(s, msgN) || hit(s, channelWords) || nameAfter(c, v + 1).isNotEmpty())) {
            val ch = if ("sms" in s) "sms" else if (hit(s, setOf("facebook", "messenger"))) "fb" else "wa"
            return Cmd("SEND", arg = nameAfter(c, v + 1), body = bodyAfter(c), channel = ch)
        }
        v = firstIdx(c, replyV)
        if (v >= 0) {
            val rest = c.drop(v + 1)
            val last = rest.isNotEmpty() && rest[0] in lastWords
            return Cmd("REPLY", arg = if (last) "" else nameAfter(c, v + 1), body = bodyAfter(c), last = last)
        }
        v = firstIdx(c, callV)
        if (v >= 0) {
            val rest = c.drop(v + 1)
            val last = rest.isNotEmpty() && rest[0] in lastWords
            return Cmd("CALL", arg = if (last) "" else nameAfter(c, v + 1), last = last)
        }

        val msg = hit(s, msgN)
        val cont = hit(s, contN)
        val openv = hit(s, openV)
        if (cont && (openv || c.size <= 3)) return Cmd("OPEN", arg = "contacts")
        if (msg) {
            val j = firstIdx(c, msgN)
            val name = nameAfter(c, j + 1)
            if (name.isNotEmpty()) return Cmd("CHAT", arg = name)
            if (openv) return Cmd("OPEN", arg = "messages")
            return Cmd("READ")
        }
        if (openv) {
            val ov = firstIdx(c, openV)
            val rest = c.drop(ov + 1).filter { it !in articles }
            if (hit(s, setOf("chamadas", "telefone", "teclado", "dialer", "marcador"))) return Cmd("OPEN", arg = "dialer")
            if (hit(s, setOf("definicoes", "configuracoes", "settings"))) return Cmd("OPEN", arg = "settings")
            if (hit(s, setOf("camara", "camera"))) return Cmd("OPEN", arg = "camera")
            if (rest.isNotEmpty()) return Cmd("OPEN", arg = "app:" + rest.joinToString(" "))
            return null
        }
        if (c.size <= 3 && hit(s, appBare)) {
            val t = c.first { it in appBare }
            return Cmd("OPEN", arg = "app:$t")
        }
        if (hit(s, setOf("ajuda", "help"))) return Cmd("HELP")
        return null
    }

    /** Devolve os pedidos percebidos, por ordem. Lista vazia = não percebi nada (ex.: só a palavra de ativação). */
    fun parse(text: String): List<Cmd> {
        val t = clean(text)
        if (t.isEmpty()) return emptyList()
        val toks0 = t.split(" ")
        val s = toks0.toSet()
        if (("lembra" in s && "me" in s) || "lembrete" in s || ("remind" in s && "me" in s) || ("avisa" in s && "me" in s)) {
            return listOf(Cmd("REMIND", raw = t))
        }
        if ("notas" in s && hit(s, setOf("apaga", "apagar", "limpa", "delete", "clear"))) return listOf(Cmd("NOTE_CLEAR"))
        if ("notas" in s && (hit(s, readV) || "minhas" in s || "my" in s)) return listOf(Cmd("NOTE_READ"))
        if ("anota" in s || ("nota" in s && hit(s, setOf("toma", "tomar", "guarda", "nova", "take")))) {
            return listOf(Cmd("NOTE_ADD", raw = t))
        }
        // a mensagem a enviar (depois de "dizendo") não é corrigida
        var bi = toks0.indexOfFirst { it in bodyMarks }
        if (bi < 0) bi = toks0.size
        val toks = toks0.take(bi).map { canon(it) } + toks0.drop(bi)
        val out = ArrayList<Cmd>()
        for (c in splitClauses(toks)) {
            val cmd = clauseCmd(c)
            if (cmd != null) out.add(cmd)
        }
        return out
    }
}
