package com.holomind.app

import android.content.Context
import android.content.res.AssetManager
import android.net.Uri
import java.io.File
import java.util.zip.ZipInputStream

/**
 * Modelos de voz (Vosk): "model-pt" (obrigatório) e "model-en" (opcional, para inglês).
 * Podem vir dentro do APK (assets) ou, no caso do português, ser importados de um .zip.
 */
object ModelHelper {
    const val PT = "model-pt"
    const val EN = "model-en"
    private val rootDirs = setOf("am", "conf", "graph", "ivector", "rnnlm")
    @Volatile var importing = false

    private fun dest(ctx: Context, name: String) = File(ctx.filesDir, name)

    // O modelo pt-0.3 é "plano" (final.mdl na raiz); outros usam am/ + conf/
    private fun isModelDir(d: File) =
        File(d, "final.mdl").exists() || (File(d, "am/final.mdl").exists() && File(d, "conf/model.conf").exists())

    private fun installed(ctx: Context, name: String) = File(dest(ctx, name), ".ready").exists() && isModelDir(dest(ctx, name))

    private fun inAssets(ctx: Context, name: String): Boolean {
        val l = ctx.assets.list(name) ?: return false
        return l.contains("final.mdl") || l.contains("am")
    }

    fun hasModel(ctx: Context): Boolean = installed(ctx, PT) || inAssets(ctx, PT)
    fun hasEnglish(ctx: Context): Boolean = installed(ctx, EN) || inAssets(ctx, EN)

    fun ensure(ctx: Context): File? = ensure(ctx, PT)

    fun ensure(ctx: Context, name: String): File? {
        val d = dest(ctx, name)
        if (installed(ctx, name)) return d
        if (!inAssets(ctx, name)) return null
        d.deleteRecursively()
        copy(ctx.assets, name, d)
        File(d, ".ready").createNewFile()
        return d
    }

    private fun copy(am: AssetManager, path: String, dest: File) {
        val list = am.list(path) ?: return
        if (list.isEmpty()) {
            dest.parentFile?.mkdirs()
            am.open(path).use { i -> dest.outputStream().use { o -> i.copyTo(o) } }
        } else {
            dest.mkdirs()
            for (n in list) copy(am, "$path/$n", File(dest, n))
        }
    }

    /** Descompacta um zip de modelo Vosk (português) escolhido pelo utilizador. Devolve true se ficou válido. */
    fun importZip(ctx: Context, uri: Uri): Boolean {
        val tmp = File(ctx.filesDir, "model-tmp")
        tmp.deleteRecursively(); tmp.mkdirs()
        val tmpPath = tmp.canonicalPath + File.separator
        val input = ctx.contentResolver.openInputStream(uri) ?: return false
        ZipInputStream(input.buffered()).use { zin ->
            while (true) {
                val e = zin.nextEntry ?: break
                val parts = e.name.split('/').filter { it.isNotEmpty() }
                if (parts.isEmpty()) continue
                if (parts.size == 1 && e.isDirectory && parts[0] !in rootDirs) continue // pasta de topo
                // ignora a pasta de topo (ex.: vosk-model-small-pt-0.3/)
                val rel = if (parts.size >= 2 && parts[0] !in rootDirs) parts.drop(1) else parts
                val out = File(tmp, rel.joinToString("/"))
                if (!out.canonicalPath.startsWith(tmpPath)) continue // proteção contra caminhos maliciosos
                if (e.isDirectory) out.mkdirs() else {
                    out.parentFile?.mkdirs()
                    out.outputStream().use { zin.copyTo(it) }
                }
            }
        }
        if (!isModelDir(tmp)) {
            tmp.deleteRecursively()
            return false
        }
        val d = dest(ctx, PT)
        d.deleteRecursively()
        if (!tmp.renameTo(d)) { tmp.deleteRecursively(); return false }
        File(d, ".ready").createNewFile()
        return true
    }
}
