package com.holomind.app

import android.content.Context
import android.content.res.AssetManager
import java.io.File

object ModelHelper {
    const val ASSET_DIR = "model-pt"

    fun hasModel(ctx: Context): Boolean = ctx.assets.list(ASSET_DIR)?.contains("conf") == true

    /** Copia o modelo Vosk dos assets para o armazenamento interno (só na primeira vez). */
    fun ensure(ctx: Context): File? {
        val dest = File(ctx.filesDir, ASSET_DIR)
        val marker = File(dest, ".ready")
        if (marker.exists()) return dest
        if (!hasModel(ctx)) return null
        copy(ctx.assets, ASSET_DIR, dest)
        marker.createNewFile()
        return dest
    }

    private fun copy(am: AssetManager, path: String, dest: File) {
        val list = am.list(path) ?: return
        if (list.isEmpty()) {
            dest.parentFile?.mkdirs()
            am.open(path).use { i -> dest.outputStream().use { o -> i.copyTo(o) } }
        } else {
            dest.mkdirs()
            for (n in list) copy(am, "$path/$n", File(dest, n))
        }
    }
}
