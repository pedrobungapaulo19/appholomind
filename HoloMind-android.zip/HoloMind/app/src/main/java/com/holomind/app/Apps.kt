package com.holomind.app

import android.content.Context
import android.content.Intent

/** Encontra apps instaladas pelo nome dito ("abre o uatsapp", "open facebook") e abre-as. */
object Apps {
    data class App(val label: String, val pkg: String)

    @Volatile private var cache: List<App>? = null

    // como as pessoas dizem -> parte do nome do pacote
    private val aliases = mapOf(
        "whatsapp" to "whatsapp", "uatsapp" to "whatsapp", "vatsapp" to "whatsapp", "watsap" to "whatsapp",
        "uotsap" to "whatsapp", "zap" to "whatsapp", "zapzap" to "whatsapp",
        "facebook" to "facebook.katana", "feicebuque" to "facebook.katana", "face" to "facebook.katana",
        "messenger" to "facebook.orca", "mensageiro" to "facebook.orca",
        "instagram" to "instagram", "insta" to "instagram",
        "youtube" to "youtube", "iutube" to "youtube",
        "telegram" to "telegram", "tiktok" to "tiktok", "chrome" to "chrome", "gmail" to "gm",
        "mapas" to "maps", "maps" to "maps", "camara" to "camera", "camera" to "camera",
        "galeria" to "gallery", "fotos" to "photos", "definicoes" to "settings", "settings" to "settings",
        "relogio" to "clock", "calculadora" to "calculator", "musica" to "music", "spotify" to "spotify"
    )

    private val skip = setOf("o", "a", "os", "as", "app", "aplicativo", "aplicacao", "no", "na", "do", "da", "the", "my")

    fun list(ctx: Context): List<App> {
        cache?.let { return it }
        val pm = ctx.packageManager
        val i = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        val l = pm.queryIntentActivities(i, 0)
            .map { App(it.loadLabel(pm).toString(), it.activityInfo.packageName) }
            .distinctBy { it.pkg }
        cache = l
        return l
    }

    fun refresh() { cache = null }

    fun find(ctx: Context, spoken: String): App? {
        val q = Util.norm(spoken).split(" ").filter { it.isNotBlank() && it !in skip }.joinToString(" ")
        if (q.isBlank()) return null
        val apps = list(ctx)
        // 1) nome igual ou contido
        apps.firstOrNull { Util.norm(it.label) == q }?.let { return it }
        apps.firstOrNull { val n = Util.norm(it.label); n.length >= 3 && (n.contains(q) || q.contains(n)) }?.let { return it }
        // 2) apelidos conhecidos
        val key = aliases[q.replace(" ", "")] ?: aliases[q]
        if (key != null) apps.firstOrNull { it.pkg.contains(key) || Util.norm(it.label).contains(key) }?.let { return it }
        // 3) parecido na pronúncia
        val sq = Util.skelApp(q)
        if (sq.length >= 3) {
            apps.firstOrNull {
                val sl = Util.skelApp(it.label)
                sl.length >= 3 && Util.levenshtein(sl, sq) <= (if (sl.length >= 5) 1 else 0)
            }?.let { return it }
        }
        return null
    }

    fun launchIntent(ctx: Context, pkg: String): Intent? =
        ctx.packageManager.getLaunchIntentForPackage(pkg)?.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)

    fun isInstalled(ctx: Context, pkg: String) = ctx.packageManager.getLaunchIntentForPackage(pkg) != null
}
