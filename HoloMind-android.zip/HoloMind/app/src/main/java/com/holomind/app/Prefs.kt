package com.holomind.app

import android.content.Context
import org.json.JSONObject

class Prefs(ctx: Context) {
    companion object {
        // "HoloMind" lê-se "olomaind": variantes que o reconhecedor costuma escrever
        const val WAKE_HOLOMIND = "holomind,holo mind,olo mind,holo mine,olo mine,hollow mind,hollow mine,olo mente,olho mente,ola mente"
        const val WAKE_HOLOMAIND = "holomaind,holo maind,olo maind,olomaind,olo main,holo main,olo maine,olo mainde,hollow mind,hollow mine,olo mente,olho mente"
        const val WAKE_HOLO = "holo,olo,rolo"
        const val DEFAULT_WAKE = "holomind,holo mind,holomaind,holo maind,olo mind,olo maind,olomaind,olo main,olo mine,holo mine,hollow mind,hollow mine,olo mente,olho mente,ola mente"

        fun presetFor(choice: String): String = when (choice) {
            "holo" -> WAKE_HOLO
            "holomind" -> WAKE_HOLOMIND
            else -> WAKE_HOLOMAIND
        }

        fun labelFor(choice: String): String = when (choice) {
            "holo" -> "Holo"
            "holomind" -> "HoloMind"
            else -> "HoloMaind"
        }
    }

    private val sp = ctx.getSharedPreferences("holomind", Context.MODE_PRIVATE)

    // Como o HoloMind chama o utilizador
    var userName: String
        get() = sp.getString("userName", "") ?: ""
        set(v) = sp.edit().putString("userName", v).apply()

    // Como o utilizador chama o HoloMind (para mostrar no ecrã)
    var wakeName: String
        get() = sp.getString("wakeName", "HoloMind") ?: "HoloMind"
        set(v) = sp.edit().putString("wakeName", v).apply()

    var wakeWords: String
        get() = sp.getString("wakeWords", DEFAULT_WAKE) ?: DEFAULT_WAKE
        set(v) = sp.edit().putString("wakeWords", v).apply()

    // Limiar máximo de volume (RMS) para "acordar" o reconhecedor; o app baixa-o sozinho em ambientes calmos.
    var sensitivity: Int
        get() = sp.getInt("sensitivity", 700)
        set(v) = sp.edit().putInt("sensitivity", v).apply()

    var eco: Boolean
        get() = sp.getBoolean("eco", false)
        set(v) = sp.edit().putBoolean("eco", v).apply()

    var quietEnabled: Boolean
        get() = sp.getBoolean("quietEnabled", false)
        set(v) = sp.edit().putBoolean("quietEnabled", v).apply()

    var quietStart: Int
        get() = sp.getInt("quietStart", 23)
        set(v) = sp.edit().putInt("quietStart", v).apply()

    var quietEnd: Int
        get() = sp.getInt("quietEnd", 6)
        set(v) = sp.edit().putInt("quietEnd", v).apply()

    var minBattery: Int
        get() = sp.getInt("minBattery", 15)
        set(v) = sp.edit().putInt("minBattery", v).apply()

    // Mantém o CPU acordado com o ecrã desligado (mais fiável, gasta mais bateria)
    var wakeLock: Boolean
        get() = sp.getBoolean("wakeLock", false)
        set(v) = sp.edit().putBoolean("wakeLock", v).apply()

    // Avisa mensagens novas quando há auscultadores/Bluetooth ligados
    var driveMode: Boolean
        get() = sp.getBoolean("driveMode", false)
        set(v) = sp.edit().putBoolean("driveMode", v).apply()

    var ttsRate: Int
        get() = sp.getInt("ttsRate", 100)
        set(v) = sp.edit().putInt("ttsRate", v).apply()

    var ttsPitch: Int
        get() = sp.getInt("ttsPitch", 100)
        set(v) = sp.edit().putInt("ttsPitch", v).apply()

    var onboarded: Boolean
        get() = sp.getBoolean("onboarded", false)
        set(v) = sp.edit().putBoolean("onboarded", v).apply()

    // Incrementa quando a configuração muda, para o serviço recarregar sem reiniciar
    var rev: Int
        get() = sp.getInt("rev", 0)
        set(v) = sp.edit().putInt("rev", v).apply()

    var serviceEnabled: Boolean
        get() = sp.getBoolean("serviceEnabled", false)
        set(v) = sp.edit().putBoolean("serviceEnabled", v).apply()

    fun wakeWordList(): List<String> =
        wakeWords.split(",").map { Util.norm(it) }.filter { it.isNotBlank() && !Util.isCommon(it) }

    /** Gramática do reconhecedor inglês (HoloMind lê-se "hollow mind"): só reconhece estas frases ou [unk]. */
    fun enGrammar(): String =
        if (wakeName == "Holo") "[\"hollow\", \"halo\", \"[unk]\"]"
        else "[\"hollow mind\", \"halo mind\", \"hello mind\", \"[unk]\"]"

    fun toJson(): JSONObject = JSONObject()
        .put("userName", userName).put("wakeName", wakeName).put("wakeWords", wakeWords)
        .put("sensitivity", sensitivity).put("eco", eco)
        .put("quietEnabled", quietEnabled).put("quietStart", quietStart)
        .put("quietEnd", quietEnd).put("minBattery", minBattery)
        .put("wakeLock", wakeLock).put("driveMode", driveMode)
        .put("ttsRate", ttsRate).put("ttsPitch", ttsPitch)
        .put("onboarded", onboarded)

    fun fromJson(j: JSONObject) {
        userName = j.optString("userName", userName).trim().take(40)
        wakeWords = j.optString("wakeWords", wakeWords).take(200)
        sensitivity = j.optInt("sensitivity", sensitivity).coerceIn(150, 4000)
        eco = j.optBoolean("eco", eco)
        wakeLock = j.optBoolean("wakeLock", wakeLock)
        driveMode = j.optBoolean("driveMode", driveMode)
        quietEnabled = j.optBoolean("quietEnabled", quietEnabled)
        quietStart = j.optInt("quietStart", quietStart).coerceIn(0, 23)
        quietEnd = j.optInt("quietEnd", quietEnd).coerceIn(0, 23)
        minBattery = j.optInt("minBattery", minBattery).coerceIn(0, 50)
        ttsRate = j.optInt("ttsRate", ttsRate).coerceIn(50, 160)
        ttsPitch = j.optInt("ttsPitch", ttsPitch).coerceIn(60, 140)
        rev = rev + 1
    }
}
