package com.holomind.app

import android.content.Context
import org.json.JSONObject

class Prefs(ctx: Context) {
    companion object {
        // "HoloMind" lê-se "olomaind": variantes que o reconhecedor costuma escrever
        const val DEFAULT_WAKE = "holomind,holo mind,holomaind,holo maind,olo mind,olo maind,olomaind,olo main,olo mine,holo mine,hollow mind,hollow mine,olo mente,olho mente,ola mente"
    }

    private val sp = ctx.getSharedPreferences("holomind", Context.MODE_PRIVATE)

    var userName: String
        get() = sp.getString("userName", "") ?: ""
        set(v) = sp.edit().putString("userName", v).apply()

    // Variantes do que o reconhecedor pode "ouvir" quando se diz HoloMind (ajuste pelo Logcat)
    var wakeWords: String
        get() = sp.getString("wakeWords", DEFAULT_WAKE) ?: DEFAULT_WAKE
        set(v) = sp.edit().putString("wakeWords", v).apply()

    // Limiar de volume (RMS) para "acordar" o reconhecedor. Maior = menos sensível = menos bateria.
    var sensitivity: Int
        get() = sp.getInt("sensitivity", 700)
        set(v) = sp.edit().putInt("sensitivity", v).apply()

    var eco: Boolean
        get() = sp.getBoolean("eco", false)
        set(v) = sp.edit().putBoolean("eco", v).apply()

    var quietEnabled: Boolean
        get() = sp.getBoolean("quietEnabled", false)
        set(v) = sp.edit().putBoolean("quietEnabled", v).apply()

    var quietStart: Int
        get() = sp.getInt("quietStart", 23)
        set(v) = sp.edit().putInt("quietStart", v).apply()

    var quietEnd: Int
        get() = sp.getInt("quietEnd", 6)
        set(v) = sp.edit().putInt("quietEnd", v).apply()

    var minBattery: Int
        get() = sp.getInt("minBattery", 15)
        set(v) = sp.edit().putInt("minBattery", v).apply()

    // Mantém o CPU acordado com o ecrã desligado (mais fiável, gasta mais bateria)
    var wakeLock: Boolean
        get() = sp.getBoolean("wakeLock", false)
        set(v) = sp.edit().putBoolean("wakeLock", v).apply()

    // Incrementa quando a configuração muda, para o serviço recarregar sem reiniciar
    var rev: Int
        get() = sp.getInt("rev", 0)
        set(v) = sp.edit().putInt("rev", v).apply()

    var serviceEnabled: Boolean
        get() = sp.getBoolean("serviceEnabled", false)
        set(v) = sp.edit().putBoolean("serviceEnabled", v).apply()

    fun wakeWordList(): List<String> =
        wakeWords.split(",").map { Util.norm(it) }.filter { it.isNotBlank() }

    fun toJson(): JSONObject = JSONObject()
        .put("userName", userName).put("wakeWords", wakeWords)
        .put("sensitivity", sensitivity).put("eco", eco)
        .put("quietEnabled", quietEnabled).put("quietStart", quietStart)
        .put("quietEnd", quietEnd).put("minBattery", minBattery).put("wakeLock", wakeLock)

    fun fromJson(j: JSONObject) {
        userName = j.optString("userName", userName).trim().take(40)
        wakeWords = j.optString("wakeWords", wakeWords).take(200)
        sensitivity = j.optInt("sensitivity", sensitivity).coerceIn(150, 4000)
        eco = j.optBoolean("eco", eco)
        wakeLock = j.optBoolean("wakeLock", wakeLock)
        quietEnabled = j.optBoolean("quietEnabled", quietEnabled)
        quietStart = j.optInt("quietStart", quietStart).coerceIn(0, 23)
        quietEnd = j.optInt("quietEnd", quietEnd).coerceIn(0, 23)
        minBattery = j.optInt("minBattery", minBattery).coerceIn(0, 50)
        rev = rev + 1
    }
}
