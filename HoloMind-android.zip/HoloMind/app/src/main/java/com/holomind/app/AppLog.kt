package com.holomind.app

import android.util.Log
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/** Registo curto visível na própria app (útil quando não há computador para ver o Logcat). */
object AppLog {
    private val lines = ArrayDeque<String>()
    private val fmt = SimpleDateFormat("HH:mm:ss", Locale.US)

    @Synchronized fun add(msg: String) {
        Log.d("HoloMind", msg)
        lines.addLast("${fmt.format(Date())}  $msg")
        while (lines.size > 60) lines.removeFirst()
    }

    @Synchronized fun recent(n: Int): List<String> = lines.toList().takeLast(n).reversed()

    @Synchronized fun all(): String = lines.joinToString("\n")
}
