package com.holomind.app

import android.Manifest
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import androidx.core.app.NotificationCompat
import androidx.core.content.ContextCompat

/**
 * Após reiniciar (ou atualizar a app) tenta ligar a escuta sozinho.
 * Se o Android recusar, mostra uma notificação: um toque reativa.
 */
class BootReceiver : BroadcastReceiver() {
    override fun onReceive(c: Context, i: Intent) {
        if (i.action != Intent.ACTION_BOOT_COMPLETED && i.action != Intent.ACTION_MY_PACKAGE_REPLACED) return
        if (!Prefs(c).serviceEnabled) return
        if (c.checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) return
        try {
            ContextCompat.startForegroundService(c, Intent(c, ListenService::class.java))
            AppLog.add("Escuta iniciada após arranque")
        } catch (e: Exception) {
            AppLog.add("Arranque automático recusado (${e.javaClass.simpleName})")
            askToReactivate(c)
        }
    }

    private fun askToReactivate(c: Context) {
        if (Build.VERSION.SDK_INT >= 33 &&
            c.checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) return
        val nm = c.getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(
            NotificationChannel("holomind_boot", "Reativação", NotificationManager.IMPORTANCE_DEFAULT)
        )
        val pi = PendingIntent.getActivity(
            c, 1,
            Intent(c, MainActivity::class.java).putExtra("autostart", true).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        nm.notify(
            2,
            NotificationCompat.Builder(c, "holomind_boot")
                .setSmallIcon(android.R.drawable.ic_btn_speak_now)
                .setContentTitle("HoloMind está desligado")
                .setContentText("Toque para reativar a escuta.")
                .setContentIntent(pi).setAutoCancel(true).build()
        )
    }
}
