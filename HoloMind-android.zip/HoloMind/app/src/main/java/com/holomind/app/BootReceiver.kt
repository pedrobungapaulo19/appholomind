package com.holomind.app

import android.Manifest
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import androidx.core.app.NotificationCompat

/**
 * No Android 14+ não é permitido iniciar um serviço de microfone a partir do boot.
 * Por isso mostramos uma notificação: um toque reativa o HoloMind.
 */
class BootReceiver : BroadcastReceiver() {
    override fun onReceive(c: Context, i: Intent) {
        if (i.action != Intent.ACTION_BOOT_COMPLETED) return
        if (!Prefs(c).serviceEnabled) return
        if (Build.VERSION.SDK_INT >= 33 &&
            c.checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) return
        val nm = c.getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(
            NotificationChannel("holomind_boot", "Reativação", NotificationManager.IMPORTANCE_DEFAULT)
        )
        val pi = PendingIntent.getActivity(
            c, 1,
            Intent(c, MainActivity::class.java).putExtra("autostart", true).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val n = NotificationCompat.Builder(c, "holomind_boot")
            .setSmallIcon(android.R.drawable.ic_btn_speak_now)
            .setContentTitle("HoloMind está desligado")
            .setContentText("Toque para reativar a escuta.")
            .setContentIntent(pi).setAutoCancel(true).build()
        nm.notify(2, n)
    }
}
