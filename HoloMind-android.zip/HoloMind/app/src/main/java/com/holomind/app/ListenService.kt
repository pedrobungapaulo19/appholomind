package com.holomind.app

import android.Manifest
import android.annotation.SuppressLint
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Intent
import android.content.pm.PackageManager
import android.content.pm.ServiceInfo
import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioManager
import android.media.AudioRecord
import android.media.MediaRecorder
import android.graphics.PixelFormat
import android.os.BatteryManager
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.PowerManager
import android.provider.Settings
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import android.view.Gravity
import android.view.View
import android.view.WindowManager
import androidx.core.app.NotificationCompat
import androidx.core.app.ServiceCompat
import androidx.core.content.ContextCompat
import org.json.JSONObject
import org.vosk.Model
import org.vosk.Recognizer
import java.util.ArrayDeque
import java.util.Calendar
import java.util.Locale
import java.util.UUID
import java.util.concurrent.CountDownLatch
import java.util.concurrent.TimeUnit

/**
 * Serviço em primeiro plano que fica à escuta da palavra de ativação.
 *
 * Poupança de bateria:
 *  - VAD por energia: o reconhecedor (caro) só corre quando há som acima do limiar.
 *  - Dorme (microfone fechado) em horário de silêncio, com bateria baixa ou durante chamadas.
 *  - Modo ECO: pausas curtas no microfone enquanto há silêncio.
 */
class ListenService : Service(), TextToSpeech.OnInitListener {

    companion object {
        const val CHANNEL = "holomind_listen"
        const val CHANNEL_REMIND = "holomind_remind"
        const val NOTIF_ID = 1
        const val SR = 16000
        const val ACTION_STOP = "com.holomind.app.STOP"
        @Volatile var isRunning = false
        @Volatile var level = 0
        @Volatile var status = "Desligado"
        @Volatile var lastHeard = ""
        @Volatile var thrEff = 0
        @Volatile var learning = 0          // frases que ainda faltam ouvir no modo "Ensinar"
        @Volatile var learnMsg = ""
        @Volatile var learnDeadline = 0L
        // pedidos da interface (onboarding): perguntar por voz / dizer uma frase
        @Volatile var askPrompt: String? = null
        @Volatile var askPhase = "idle"
        @Volatile var askText = ""
        @Volatile var sayText: String? = null

        fun announce(text: String) { sayText = text }
    }

    private lateinit var prefs: Prefs
    private var tts: TextToSpeech? = null
    @Volatile private var ttsReady = false
    @Volatile private var active = false
    private var worker: Thread? = null
    private var wl: PowerManager.WakeLock? = null
    private var anchor: View? = null

    override fun onCreate() {
        super.onCreate()
        prefs = Prefs(this)
        isRunning = true
        lastHeard = ""
        tts = TextToSpeech(this, this)
    }

    override fun onInit(status: Int) {
        if (status != TextToSpeech.SUCCESS) { AppLog.add("Voz (TTS) indisponível neste telemóvel"); return }
        tts?.setAudioAttributes(
            AudioAttributes.Builder()
                .setUsage(AudioAttributes.USAGE_ASSISTANT)
                .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH).build()
        )
        val r = tts?.setLanguage(Locale("pt", "PT"))
        if (r == TextToSpeech.LANG_MISSING_DATA || r == TextToSpeech.LANG_NOT_SUPPORTED) {
            tts?.setLanguage(Locale("pt", "BR"))
        }
        ttsReady = true
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) {
            prefs.serviceEnabled = false
            AppLog.add("Desligado pela notificação")
            stopSelf()
            return START_NOT_STICKY
        }
        createChannel()
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            AppLog.add("Falta a permissão do microfone")
            stopSelf(); return START_NOT_STICKY
        }
        try {
            ServiceCompat.startForeground(
                this, NOTIF_ID, buildNotif("A iniciar…"), ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE
            )
        } catch (e: Exception) {
            AppLog.add("O Android não deixou iniciar em segundo plano (${e.javaClass.simpleName}). Abra a app e toque em Ligar.")
            stopSelf(); return START_NOT_STICKY
        }
        addAnchor()
        if (worker == null) {
            active = true
            worker = Thread({ loop() }, "holomind-loop").also { it.start() }
        }
        return START_STICKY
    }

    override fun onDestroy() {
        active = false
        isRunning = false
        level = 0
        askPrompt = null
        sayText = null
        if (!status.startsWith("Modelo") && !status.startsWith("Erro")) status = "Desligado"
        worker?.interrupt()
        releaseWakeLock()
        removeAnchor()
        tts?.shutdown()
        super.onDestroy()
    }

    // ---------------------------------------------------------------- ciclo principal

    private fun loop() {
        var model: Model? = null
        var modelEn: Model? = null
        try {
            if (!ModelHelper.hasModel(this)) {
                post("Modelo de voz em falta")
                AppLog.add("Falta o modelo de voz em assets/model-pt (ver README)")
                prefs.serviceEnabled = false
                stopSelf(); return
            }
            post("A preparar o modelo de voz…")
            val dir = ModelHelper.ensure(this) ?: run { post("Modelo de voz em falta"); stopSelf(); return }
            model = Model(dir.absolutePath)
            AppLog.add("Modelo de voz carregado")
            val dirEn = ModelHelper.ensure(this, ModelHelper.EN)
            if (dirEn != null) {
                try {
                    modelEn = Model(dirEn.absolutePath)
                    AppLog.add("Modelo inglês carregado")
                } catch (t: Throwable) {
                    AppLog.add("Modelo inglês indisponível: ${t.message}")
                }
            } else AppLog.add("Sem modelo inglês (só português)")
            while (active) {
                applyWakeLock()
                serveRequests(model, modelEn)
                val why = sleepReason()
                if (why != null) { level = 0; post("A dormir: $why"); sleepMs(15_000); continue }
                if (waitForWakeWord(model, modelEn)) onWake(model, modelEn)
            }
        } catch (t: Throwable) {
            AppLog.add("Erro: ${t.message}")
            post("Erro: ${t.message}")
        } finally {
            model?.close()
            modelEn?.close()
            releaseWakeLock()
        }
    }

    /** Pedidos da interface (perguntas por voz, frases), avisos do modo condução e lembretes vencidos. */
    private fun serveRequests(model: Model, modelEn: Model?) {
        val sy = sayText
        if (sy != null) { sayText = null; speak(sy) }

        val ap = askPrompt
        if (ap != null) {
            askPhase = "speaking"
            askText = ""
            speak(ap)
            askPhase = "listening"
            val txt = listenOnce(model, null, 9000, true)
            askText = txt
            askPhase = "done"
            askPrompt = null
        }

        for (rem in Memory.popDue(this, System.currentTimeMillis())) {
            AppLog.add("Lembrete: $rem")
            remindNotify(rem)
            speak("Lembrete: $rem")
        }
    }

    /** true = ouviu a palavra de ativação; false = reavaliar (sono, nova configuração, pedido da interface, erro, parar). */
    private fun waitForWakeWord(model: Model, modelEn: Model?): Boolean {
        val rec = openRecorder() ?: run { post("Microfone ocupado — a tentar de novo"); sleepMs(5000); return false }
        post("À escuta de “${prefs.wakeName}”")
        val words = prefs.wakeWordList()
        val grammar = prefs.enGrammar()
        val base = prefs.sensitivity.toDouble()
        val rev0 = prefs.rev
        val buf = ShortArray(1600) // 100 ms
        val pre = ArrayDeque<ShortArray>() // ~400 ms antes de o som começar
        var r: Recognizer? = null   // português, texto livre
        var re: Recognizer? = null  // inglês, só a frase da palavra de ativação ("hollow mind")
        var quiet = 0; var activeChunks = 0; var idle = 0; var tick = 0; var errors = 0
        var floor = 150.0 // ruído de fundo estimado
        var agc = 1.0     // ganho suave para vozes distantes/baixas
        rec.startRecording()
        try {
            while (active) {
                val n = rec.read(buf, 0, buf.size)
                if (n < 0) { if (++errors > 20) return false; sleepMs(200); continue }
                if (n == 0) continue
                errors = 0
                if (askPrompt != null || sayText != null) return false
                val e = Util.rms(buf, n)
                level = e.toInt()
                // limiar adaptativo: 2,8x o ruído de fundo, nunca acima do definido pelo utilizador
                val thr = minOf(base, maxOf(120.0, floor * 2.8))
                thrEff = thr.toInt()
                val loud = e > thr
                if (!loud) floor = 0.97 * floor + 0.03 * e
                if (loud) agc = 0.8 * agc + 0.2 * (1500.0 / maxOf(e, 1.0)).coerceIn(1.0, 4.0)

                if (++tick % 50 == 0) {
                    if (sleepReason() != null || prefs.rev != rev0) return false
                    val due = Memory.nextDue(this)
                    if (due > 0 && due <= System.currentTimeMillis()) return false
                }
                if (learning > 0 && tick % 10 == 0 && System.currentTimeMillis() > learnDeadline) {
                    learning = 0
                    learnMsg = "Tempo esgotado. Toque em Ensinar e tente de novo."
                }

                if (r == null) {
                    pre.addLast(buf.copyOf(n)); if (pre.size > 4) pre.removeFirst()
                    if (loud) {
                        r = Recognizer(model, SR.toFloat())
                        re = if (modelEn != null) Recognizer(modelEn, SR.toFloat(), grammar) else null
                        quiet = 0; activeChunks = 0
                        for (c in pre) {
                            scale(c, c.size, agc)
                            r.acceptWaveForm(c, c.size)
                            re?.acceptWaveForm(c, c.size)
                        }
                        pre.clear()
                    } else if (prefs.eco && ++idle >= 10) {
                        idle = 0; rec.stop(); sleepMs(300); rec.startRecording()
                    }
                    continue
                }

                scale(buf, n, agc)
                val end = r.acceptWaveForm(buf, n)
                val endEn = re?.acceptWaveForm(buf, n) ?: false
                val txt = if (end) JSONObject(r.result).optString("text")
                          else JSONObject(r.partialResult).optString("partial")
                val txtEn = if (re == null) "" else if (endEn) JSONObject(re.result).optString("text")
                            else JSONObject(re.partialResult).optString("partial")
                if (txt.isNotBlank()) lastHeard = txt else if (txtEn.isNotBlank()) lastHeard = txtEn
                if (end && txt.isNotBlank()) AppLog.add("Ouvi: “$txt”")
                if (endEn && txtEn.isNotBlank()) AppLog.add("Ouvi (EN): “$txtEn”")
                if (learning > 0) {
                    if (end && txt.isNotBlank()) learnPhrase(txt)
                } else if (Util.isWake(txt, words) || enWake(txtEn)) {
                    AppLog.add("Ativado por “" + (if (txtEn.isNotBlank() && enWake(txtEn)) txtEn else txt) + "”")
                    return true
                }
                if (end) { r.close(); re?.close(); r = null; re = null; continue }
                quiet = if (loud) 0 else quiet + 1
                if (quiet > 15 || ++activeChunks > 150) { r.close(); re?.close(); r = null; re = null }
            }
            return false
        } finally {
            r?.close()
            re?.close()
            level = 0
            try { rec.stop() } catch (_: Exception) {}
            rec.release()
        }
    }

    /** O reconhecedor inglês ouve "HoloMind" como "hollow mind" / "halo mind". */
    private fun enWake(t: String): Boolean {
        val s = t.lowercase()
        if (s.isBlank()) return false
        return if (prefs.wakeName == "Holo") s.contains("hollow") || s.contains("halo")
        else s.contains("mind") && (s.contains("hollow") || s.contains("halo") || s.contains("hello") || s.contains("holo"))
    }

    private fun scale(b: ShortArray, n: Int, g: Double) {
        if (g < 1.02) return
        for (i in 0 until n) b[i] = (b[i] * g).toInt().coerceIn(-32768, 32767).toShort()
    }

    /** Modo "Ensinar": guarda como o reconhecedor escreve a palavra de ativação na voz do utilizador. */
    private fun learnPhrase(txt: String) {
        val t = Util.norm(txt)
        if (t.isBlank() || t.split(" ").size > 3 || Util.isCommon(t)) {
            AppLog.add("Ensinar: frase ignorada (diga só ${prefs.wakeName})")
            return
        }
        val cur = prefs.wakeWordList().toMutableList()
        if (t !in cur && prefs.wakeWords.length < 180) {
            cur.add(t)
            prefs.wakeWords = cur.joinToString(",")
        }
        learning -= 1
        AppLog.add("Aprendi: “$t”")
        learnMsg = if (learning > 0) "Boa! Falta $learning vez(es)…" else "Pronto! O HoloMind aprendeu a sua voz."
        if (learning == 0) prefs.rev = prefs.rev + 1
    }

    private fun onWake(model: Model, modelEn: Model?) {
        post("A ouvir o seu pedido…")
        Memory.recordUse(this)
        val name = prefs.userName
        speak(if (name.isBlank()) "Estou à escuta." else "Estou à escuta, $name.")
        val io = Commands.Io(speak = { speak(it) }, listen = { listenOnce(model, modelEn, 6000) })
        var cmd = listenOnce(model, modelEn, 7000)
        var turns = 0
        while (cmd.isNotBlank() && turns < 5 && active) {
            AppLog.add("Pedido: “$cmd”")
            var reply = try { Commands.handle(this, cmd, io) } catch (t: Throwable) {
                AppLog.add("Erro no pedido: ${t.message}"); "Ocorreu um erro."
            }
            if (reply == Commands.UNKNOWN && turns == 0) reply = learnUnknown(cmd, io)
            if (reply.isBlank()) break
            if (reply == Commands.UNKNOWN && turns > 0) break
            AppLog.add("Resposta: “$reply”")
            speak(reply)
            turns++
            cmd = listenOnce(model, modelEn, 5000) // continua a conversa sem repetir a palavra de ativação
        }
        if (turns == 0 && cmd.isBlank()) AppLog.add("Nenhum pedido ouvido")
        sleepMs(300)
    }

    /** Pedido desconhecido: pergunta o que era e aprende a frase para a próxima vez. */
    private fun learnUnknown(cmd: String, io: Commands.Io): String {
        io.speak("Ainda não sei o que quer dizer com ${cmd}. O que queria fazer? Diga, por exemplo: mensagens, horas, bateria, lanterna ou volume.")
        val ans = io.listen()
        val key = Commands.learnableKey(Util.norm(ans)) ?: return "Está bem, não aprendi essa."
        Memory.setCustom(this, Util.norm(cmd), key)
        AppLog.add("Aprendi a frase “$cmd” → $key")
        return "Aprendi. " + Commands.run(this, key, io)
    }

    private val enShort = setOf("yes", "yeah", "ok", "okay", "confirm", "send", "send it", "no", "cancel", "stop")

    /** Escolhe entre o texto do reconhecedor português e o do inglês: fica o que corresponde a um pedido conhecido. */
    private fun pickText(tp: String, te: String): String {
        if (te.isBlank()) return tp
        if (tp.isNotBlank() && Commands.understands(this, tp)) return tp
        if (Commands.understands(this, te) || te.trim().lowercase() in enShort) return te
        return tp.ifBlank { te }
    }

    private fun listenOnce(model: Model, modelEn: Model?, maxMs: Long, live: Boolean = false): String {
        val rec = openRecorder() ?: return ""
        val r = Recognizer(model, SR.toFloat())
        val re: Recognizer? = if (!live && modelEn != null) Recognizer(modelEn, SR.toFloat()) else null
        val buf = ShortArray(1600)
        val start = System.currentTimeMillis()
        var heard = false
        rec.startRecording()
        try {
            while (active && System.currentTimeMillis() - start < maxMs) {
                val n = rec.read(buf, 0, buf.size)
                if (n < 0) break
                if (n == 0) continue
                val e = Util.rms(buf, n)
                level = e.toInt()
                scale(buf, n, if (e < 40) 1.0 else (1500.0 / e).coerceIn(1.0, 3.0))
                re?.acceptWaveForm(buf, n)
                if (r.acceptWaveForm(buf, n)) {
                    val tp = JSONObject(r.result).optString("text")
                    val te = if (re != null) JSONObject(re.finalResult).optString("text") else ""
                    val pick = pickText(tp, te)
                    if (pick.isNotBlank()) return pick
                } else {
                    val part = JSONObject(r.partialResult).optString("partial")
                    if (part.isNotBlank()) {
                        heard = true
                        if (live) askText = part
                    } else if (!heard && System.currentTimeMillis() - start > 4000) {
                        break
                    }
                }
            }
            val tp = JSONObject(r.finalResult).optString("text")
            val te = if (re != null) JSONObject(re.finalResult).optString("text") else ""
            return pickText(tp, te)
        } finally {
            level = 0
            r.close()
            re?.close()
            try { rec.stop() } catch (_: Exception) {}
            rec.release()
        }
    }

    // ---------------------------------------------------------------- utilitários

    @SuppressLint("MissingPermission")
    private fun openRecorder(): AudioRecord? {
        val min = AudioRecord.getMinBufferSize(SR, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT)
        val r = try {
            AudioRecord(
                MediaRecorder.AudioSource.VOICE_RECOGNITION, SR,
                AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT, maxOf(min, 8000)
            )
        } catch (e: Exception) { AppLog.add("Microfone: ${e.message}"); return null }
        if (r.state != AudioRecord.STATE_INITIALIZED) { r.release(); return null }
        return r
    }

    private fun sleepReason(): String? {
        val bm = getSystemService(BatteryManager::class.java)
        val pct = bm.getIntProperty(BatteryManager.BATTERY_PROPERTY_CAPACITY)
        if (!bm.isCharging && pct in 1 until prefs.minBattery) return "bateria baixa ($pct%)"
        val mode = getSystemService(AudioManager::class.java).mode
        if (mode == AudioManager.MODE_IN_CALL || mode == AudioManager.MODE_IN_COMMUNICATION ||
            mode == AudioManager.MODE_RINGTONE) return "em chamada"
        if (prefs.quietEnabled) {
            val h = Calendar.getInstance().get(Calendar.HOUR_OF_DAY)
            val s = prefs.quietStart; val e = prefs.quietEnd
            val quiet = if (s < e) h in s until e else (h >= s || h < e)
            if (quiet) return "horário de silêncio"
        }
        return null
    }

    @SuppressLint("WakelockTimeout")
    private fun applyWakeLock() {
        if (prefs.wakeLock) {
            if (wl?.isHeld != true) {
                wl = getSystemService(PowerManager::class.java)
                    .newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "holomind:listen").also { it.acquire() }
            }
        } else releaseWakeLock()
    }

    private fun releaseWakeLock() {
        try { if (wl?.isHeld == true) wl?.release() } catch (_: Exception) {}
        wl = null
    }

    private fun sleepMs(ms: Long) {
        try { Thread.sleep(ms) } catch (_: InterruptedException) {}
    }

    /** Fala frase a frase, escolhendo voz portuguesa ou inglesa conforme o idioma de cada frase. */
    private fun speak(text: String) {
        if (text.isBlank()) return
        val parts = text.split(Regex("(?<=[.!?])\\s+")).map { it.trim() }.filter { it.isNotEmpty() }
        for (p in parts) speakOne(p, Util.looksEnglish(p))
    }

    private fun speakOne(text: String, english: Boolean) {
        val t = tts
        if (!ttsReady || t == null) { AppLog.add("Voz ainda não está pronta"); return }
        var r = t.setLanguage(if (english) Locale.US else Locale("pt", "PT"))
        if (r == TextToSpeech.LANG_MISSING_DATA || r == TextToSpeech.LANG_NOT_SUPPORTED) {
            r = t.setLanguage(if (english) Locale.ENGLISH else Locale("pt", "BR"))
        }
        val latch = CountDownLatch(1)
        t.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
            override fun onStart(utteranceId: String?) {}
            override fun onDone(utteranceId: String?) { latch.countDown() }
            @Deprecated("Deprecated in Java")
            override fun onError(utteranceId: String?) { latch.countDown() }
        })
        t.setSpeechRate(prefs.ttsRate / 100f)
        t.setPitch(prefs.ttsPitch / 100f)
        t.speak(text, TextToSpeech.QUEUE_FLUSH, null, UUID.randomUUID().toString())
        latch.await(25, TimeUnit.SECONDS)
    }

    /** Âncora de 1 pixel: com a permissão "aparecer por cima", o Android deixa abrir apps a partir do segundo plano. */
    private fun addAnchor() {
        if (!Settings.canDrawOverlays(this)) return
        Handler(Looper.getMainLooper()).post {
            if (anchor != null) return@post
            try {
                val wm = getSystemService(WindowManager::class.java)
                val v = View(this)
                val lp = WindowManager.LayoutParams(
                    1, 1, WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
                    WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE,
                    PixelFormat.TRANSLUCENT
                )
                lp.gravity = Gravity.TOP or Gravity.START
                wm.addView(v, lp)
                anchor = v
            } catch (e: Exception) {
                AppLog.add("Sobreposição indisponível: ${e.message}")
            }
        }
    }

    private fun removeAnchor() {
        val v = anchor ?: return
        anchor = null
        Handler(Looper.getMainLooper()).post {
            try { getSystemService(WindowManager::class.java).removeView(v) } catch (_: Exception) {}
        }
    }

    private fun createChannel() {
        getSystemService(NotificationManager::class.java).createNotificationChannel(
            NotificationChannel(CHANNEL, "HoloMind à escuta", NotificationManager.IMPORTANCE_LOW)
        )
    }

    private fun remindNotify(text: String) {
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel(CHANNEL_REMIND, "Lembretes", NotificationManager.IMPORTANCE_HIGH))
        nm.notify(
            (System.currentTimeMillis() % 100000).toInt() + 10,
            NotificationCompat.Builder(this, CHANNEL_REMIND)
                .setSmallIcon(android.R.drawable.ic_btn_speak_now)
                .setContentTitle("Lembrete")
                .setContentText(text)
                .setAutoCancel(true).build()
        )
    }

    private fun buildNotif(text: String) = NotificationCompat.Builder(this, CHANNEL)
        .setSmallIcon(android.R.drawable.ic_btn_speak_now)
        .setContentTitle("HoloMind")
        .setContentText(text)
        .setOngoing(true)
        .setContentIntent(
            PendingIntent.getActivity(
                this, 0, Intent(this, MainActivity::class.java),
                PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
            )
        )
        .addAction(
            0, "Parar",
            PendingIntent.getService(
                this, 3, Intent(this, ListenService::class.java).setAction(ACTION_STOP),
                PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
            )
        ).build()

    private fun post(text: String) {
        if (text == status) return
        status = text
        AppLog.add(text)
        getSystemService(NotificationManager::class.java).notify(NOTIF_ID, buildNotif(text))
    }
}
