package com.holomind.app

import android.Manifest
import android.annotation.SuppressLint
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.RemoteInput
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.hardware.camera2.CameraCharacteristics
import android.hardware.camera2.CameraManager
import android.media.AudioManager
import android.net.Uri
import android.os.BatteryManager
import android.os.Build
import android.os.Bundle
import android.provider.ContactsContract
import android.telecom.TelecomManager
import android.telephony.SmsManager
import android.telephony.TelephonyManager
import androidx.core.app.NotificationCompat
import androidx.core.content.ContextCompat
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

/** Pedidos por voz em português e inglês. */
object Commands {
    class Io(val speak: (String) -> Unit, val listen: () -> String)
    data class Contact(val display: String, val number: String, val normalized: String?)

    const val UNKNOWN = "Desculpe, ainda não sei fazer isso. Diga ajuda para saber o que posso fazer."

    private val stopWords = setOf("o", "a", "os", "as", "ao", "aos", "para", "pro", "pra", "do", "da", "de", "meu", "minha", "to", "the")
    private val pt = Locale("pt", "PT")

    private val openKeys = listOf(
        "abre o ", "abre a ", "abre ", "abrir o ", "abrir a ", "abrir ", "entra no ", "entra na ", "entrar no ",
        "entrar na ", "open the ", "open ", "launch "
    )
    private val sendKeys = arrayOf(
        "manda mensagem", "manda uma mensagem", "mandar mensagem", "mandar uma mensagem", "envia mensagem",
        "envia uma mensagem", "enviar mensagem", "enviar uma mensagem", "escreve para", "send a message",
        "send message", "send a text"
    )
    private val callKeys = arrayOf("liga para ", "ligar para ", "telefona para ", "call ", "phone ")

    /** Que tipo de pedido é? null = não percebi. */
    fun route(ctx: Context, t: String): String? {
        if (t.isBlank()) return null
        if (Memory.customAction(ctx, t) != null) return "custom"
        return when {
            has(t, "lembra me", "lembrete", "avisa me", "remind me") -> "remind"
            has(t, "apaga as notas", "apagar notas", "apaga notas", "limpa as notas", "delete notes", "clear notes") -> "notes_clear"
            has(t, "anota", "toma nota", "tomar nota", "guarda a nota", "nova nota", "take a note") -> "note_add"
            has(t, "minhas notas", "ler notas", "le as notas", "que notas", "ver notas", "read my notes") -> "notes_read"
            has(t, *sendKeys) -> "send"
            keyFor(t) != null -> "key"
            openKeys.any { t.contains(it) } -> "open"
            has(t, "liga lhe", "ligar lhe", "telefona lhe", "liga a ele", "liga a ela", "liga para ele", "liga para ela",
                "call him", "call her") -> "call_last"
            has(t, *callKeys) -> "call"
            else -> null
        }
    }

    fun understands(ctx: Context, raw: String): Boolean = route(ctx, Util.norm(raw)) != null

    /** Devolve o que o HoloMind deve dizer (vazio = ficar em silêncio). */
    fun handle(ctx: Context, raw: String, io: Io): String {
        val t = Util.norm(raw)
        if (t.isBlank()) return ""
        return when (route(ctx, t)) {
            "custom" -> run(ctx, Memory.customAction(ctx, t) ?: "", io)
            "remind" -> remind(ctx, t)
            "notes_clear" -> { Memory.clearNotes(ctx); "Notas apagadas." }
            "note_add" -> addNote(ctx, io, t)
            "notes_read" -> readNotes(ctx)
            "send" -> send(ctx, io, t)
            "key" -> run(ctx, keyFor(t) ?: "", io)
            "open" -> openApp(ctx, t)
            "call_last" -> call(ctx, io, Memory.lastContact ?: "")
            "call" -> {
                val k = callKeys.firstOrNull { t.contains(it) } ?: ""
                call(ctx, io, t.substringAfter(k).trim())
            }
            else -> UNKNOWN
        }
    }

    /** Pedidos de frase fixa (português e inglês). Também serve para aprender frases novas. */
    fun keyFor(t: String): String? = when {
        has(t, "obrigado", "obrigada", "cancelar", "esquece", "deixa", "thank you", "thanks", "cancel", "never mind") -> "fim"
        has(t, "ajuda", "o que sabes", "o que sabe", "o que podes", "o que pode", "help", "what can you do") -> "ajuda"
        has(t, "bom dia", "boa tarde", "boa noite", "good morning", "good afternoon", "good evening") -> "rotina"
        has(t, "responde lhe", "responder lhe", "responde a ele", "responde a ela", "reply to him", "reply to her") -> "responder_ultimo"
        has(t, "responde", "responder", "reply") -> "responder"
        has(t, "e a outra", "a outra mensagem", "proxima mensagem", "a seguir", "a proxima", "next message", "the other one") -> "proxima"
        has(t, "lanterna", "flashlight", "torch") ->
            if (has(t, "apaga", "desliga", "desligar", "fecha", "apagar", "turn off", "switch off", " off")) "lanterna_off" else "lanterna_on"
        has(t, "bateria", "battery") -> "bateria"
        has(t, "aumenta o volume", "sobe o volume", "mais volume", "aumentar o volume", "volume up", "louder", "turn up the volume") -> "volume_up"
        has(t, "baixa o volume", "menos volume", "diminui o volume", "diminuir o volume", "baixar o volume", "volume down", "quieter", "turn down the volume") -> "volume_down"
        has(t, "mensagem", "mensagens", "read my messages", "read messages", "my messages") -> "mensagens"
        has(t, "que horas", "horas sao", "a hora", "what time", "time is it") -> "hora"
        has(t, "que dia", "what day", "today's date") -> "dia"
        else -> null
    }

    fun learnableKey(t: String): String? = keyFor(t)?.takeIf { it != "fim" }

    fun run(ctx: Context, key: String, io: Io): String = when (key) {
        "fim" -> ""
        "ajuda" -> "Posso ler e responder mensagens, enviar mensagens pelo WhatsApp ou SMS, abrir aplicações, ligar para contactos, guardar notas e lembretes, dizer as horas e a bateria, e controlar a lanterna e o volume. Entendo português e inglês, e aprendo frases novas."
        "rotina" -> routine(ctx)
        "responder" -> reply(ctx, io, false)
        "responder_ultimo" -> reply(ctx, io, true)
        "proxima" -> readNext(ctx, io)
        "mensagens" -> readMessages(ctx, io)
        "lanterna_on" -> torch(ctx, true)
        "lanterna_off" -> torch(ctx, false)
        "bateria" -> battery(ctx)
        "volume_up" -> volume(ctx, true)
        "volume_down" -> volume(ctx, false)
        "hora" -> "São " + SimpleDateFormat("HH:mm", pt).format(Date())
        "dia" -> SimpleDateFormat("EEEE, d 'de' MMMM", pt).format(Date())
        else -> UNKNOWN
    }

    private fun has(t: String, vararg keys: String) = keys.any { t.contains(it) }

    // ------------------------------------------------------------ sistema

    private fun torch(ctx: Context, on: Boolean): String {
        return try {
            val cm = ctx.getSystemService(CameraManager::class.java)
            val id = cm.cameraIdList.firstOrNull {
                cm.getCameraCharacteristics(it).get(CameraCharacteristics.FLASH_INFO_AVAILABLE) == true
            } ?: return "Este telemóvel não tem lanterna."
            cm.setTorchMode(id, on)
            if (on) "Lanterna ligada." else "Lanterna desligada."
        } catch (e: Exception) {
            "Não consegui usar a lanterna."
        }
    }

    private fun battery(ctx: Context): String {
        val bm = ctx.getSystemService(BatteryManager::class.java)
        val pct = bm.getIntProperty(BatteryManager.BATTERY_PROPERTY_CAPACITY)
        return "A bateria está a $pct por cento" + if (bm.isCharging) " e a carregar." else "."
    }

    private fun volume(ctx: Context, up: Boolean): String {
        val am = ctx.getSystemService(AudioManager::class.java)
        am.adjustStreamVolume(
            AudioManager.STREAM_MUSIC,
            if (up) AudioManager.ADJUST_RAISE else AudioManager.ADJUST_LOWER,
            AudioManager.FLAG_SHOW_UI
        )
        return if (up) "Volume aumentado." else "Volume diminuído."
    }

    /** "Bom dia": cumprimento + horas + bateria + resumo das mensagens. */
    private fun routine(ctx: Context): String {
        val h = Calendar.getInstance().get(Calendar.HOUR_OF_DAY)
        val saud = if (h in 5..11) "Bom dia" else if (h in 12..18) "Boa tarde" else "Boa noite"
        val name = Prefs(ctx).userName
        val sb = StringBuilder(saud)
        if (name.isNotBlank()) sb.append(", ").append(name)
        sb.append(". São ").append(SimpleDateFormat("HH:mm", pt).format(Date())).append(". ")
        sb.append(battery(ctx)).append(" ")
        val senders = orderedSenders(ctx, MsgStore.recent(30))
        if (senders.isEmpty()) sb.append("Não tem mensagens novas.")
        else sb.append("Tem mensagens de ").append(senders.take(4).joinToString(", ")).append(".")
        return sb.toString()
    }

    // ------------------------------------------------------------ abrir aplicações

    private fun openApp(ctx: Context, t: String): String {
        val key = openKeys.firstOrNull { t.contains(it) } ?: return UNKNOWN
        val name = t.substringAfter(key).trim()
        if (name.isBlank()) return "Que aplicação quer abrir?"
        val app = Apps.find(ctx, name) ?: return "Não encontrei a aplicação $name."
        val i = Apps.launchIntent(ctx, app.pkg) ?: return "Não consegui abrir ${app.label}."
        return try {
            ctx.startActivity(i)
            "A abrir ${app.label}."
        } catch (e: Exception) {
            notifyOpen(ctx, "Abrir ${app.label}", i)
            "O Android não deixou abrir sozinho. Toque na notificação para abrir ${app.label}."
        }
    }

    /** Plano B quando o Android bloqueia abrir uma app em segundo plano: notificação com toque para abrir. */
    private fun notifyOpen(ctx: Context, title: String, intent: Intent) {
        val nm = ctx.getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel("holomind_open", "Abrir aplicações", NotificationManager.IMPORTANCE_HIGH))
        val pi = PendingIntent.getActivity(ctx, 7, intent, PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)
        nm.notify(
            3,
            NotificationCompat.Builder(ctx, "holomind_open")
                .setSmallIcon(android.R.drawable.ic_btn_speak_now)
                .setContentTitle(title)
                .setContentText("Toque para abrir")
                .setContentIntent(pi).setAutoCancel(true).build()
        )
    }

    // ------------------------------------------------------------ ler e responder mensagens

    private fun orderedSenders(ctx: Context, msgs: List<Msg>): List<String> =
        msgs.map { it.from }.distinct().sortedByDescending { Memory.priorityScore(ctx, it) }

    private fun readMessages(ctx: Context, io: Io): String {
        val msgs = MsgStore.recent(10)
        if (msgs.isEmpty()) return "Não tem mensagens novas."
        Memory.readSenders.clear()
        val pick = pickSender(io, orderedSenders(ctx, msgs), "De quem quer ouvir?") ?: return "Não percebi o nome."
        return readFrom(pick, msgs)
    }

    private fun readNext(ctx: Context, io: Io): String {
        val msgs = MsgStore.recent(10)
        if (msgs.isEmpty()) return "Não tem mensagens novas."
        val next = orderedSenders(ctx, msgs).firstOrNull { it !in Memory.readSenders }
            ?: return "Não há mais mensagens."
        return readFrom(next, msgs)
    }

    // Cada mensagem numa frase própria: assim o idioma (português/inglês) é detetado frase a frase ao falar.
    private fun readFrom(sender: String, msgs: List<Msg>): String {
        Memory.lastContact = sender
        Memory.readSenders.add(sender)
        return msgs.filter { it.from == sender }.take(3).reversed()
            .joinToString(". ") { "Mensagem de ${it.from}. ${it.text.take(300)}" }
    }

    private fun pickSender(io: Io, senders: List<String>, question: String): String? {
        if (senders.size == 1) return senders[0]
        io.speak("Tem mensagens de ${senders.take(4).joinToString(", ")}. $question")
        val ans = Util.norm(io.listen())
        return senders.firstOrNull { s -> Util.norm(s).split(" ").any { w -> w.length > 2 && ans.contains(w) } }
    }

    /** Responde pela ação de "resposta rápida" da notificação (WhatsApp, SMS, Telegram…), com confirmação. */
    private fun reply(ctx: Context, io: Io, useLast: Boolean): String {
        val withAction = MsgStore.recent(10).filter { it.replyAction != null }
        if (withAction.isEmpty()) return "Não há mensagens para responder."
        val senders = withAction.map { it.from }.distinct()
        val last = Memory.lastContact
        val pick: String? = when {
            useLast && last != null && last in senders -> last
            senders.size == 1 -> senders[0]
            else -> pickSender(io, orderedSenders(ctx, withAction), "A quem quer responder?")
        }
        if (pick == null) return "Não percebi o nome."
        io.speak("O que quer dizer a $pick?")
        val body = io.listen().trim()
        if (body.isBlank()) return "Não ouvi a mensagem."
        io.speak("Vou enviar: $body. Confirma?")
        if (!isYes(io.listen())) return "Cancelado."
        val m = withAction.first { it.from == pick }
        if (!sendReply(ctx, m, body)) return "Não consegui enviar."
        Memory.bumpPriority(ctx, pick)
        Memory.lastContact = pick
        return "Mensagem enviada."
    }

    private fun isYes(raw: String): Boolean {
        val ok = Util.norm(raw)
        return ok.contains("sim") || ok.contains("confirma") || ok.contains("envia") || ok.contains("yes") ||
            ok.contains("send") || ok.contains("ok")
    }

    private fun sendReply(ctx: Context, m: Msg, text: String): Boolean {
        val a = m.replyAction ?: return false
        val inputs = a.remoteInputs ?: return false
        val intent = Intent()
        val results = Bundle()
        for (ri in inputs) results.putCharSequence(ri.resultKey, text)
        RemoteInput.addResultsToIntent(inputs, intent, results)
        return try { a.actionIntent.send(ctx, 0, intent); true } catch (e: PendingIntent.CanceledException) { false }
    }

    // ------------------------------------------------------------ enviar mensagens novas (WhatsApp / SMS)

    private fun send(ctx: Context, io: Io, t: String): String {
        val channel = when {
            has(t, "sms", "mensagem de texto", "text message", "send a text") -> "sms"
            has(t, "facebook", "messenger") -> "fb"
            else -> "wa"
        }
        var after = ""
        for (m in listOf(" para o ", " para a ", " para ", " ao ", " to ")) {
            val i = t.indexOf(m)
            if (i >= 0) { after = t.substring(i + m.length); break }
        }
        var namePart = after
        var body = ""
        for (c in listOf(" dizendo que ", " dizendo ", " a dizer que ", " a dizer ", " saying that ", " saying ")) {
            val i = after.indexOf(c)
            if (i >= 0) { namePart = after.substring(0, i); body = after.substring(i + c.length).trim(); break }
        }
        for (c in listOf(" no whatsapp", " pelo whatsapp", " por whatsapp", " no zap", " por sms", " por mensagem de texto",
            " on whatsapp", " by sms", " via sms", " no facebook", " no messenger")) namePart = namePart.replace(c, "")
        var name = cleanName(namePart)
        if (name.isBlank()) { io.speak("Para quem?"); name = cleanName(io.listen()) }
        if (name.isBlank()) return "Não percebi para quem."

        if (channel == "fb") {
            val app = Apps.find(ctx, "messenger") ?: Apps.find(ctx, "facebook") ?: return "Não encontrei o Messenger."
            val i = Apps.launchIntent(ctx, app.pkg) ?: return "Não consegui abrir o Messenger."
            return try {
                ctx.startActivity(i)
                "Ainda não consigo enviar pelo Facebook. Abri o ${app.label} para si."
            } catch (e: Exception) { notifyOpen(ctx, "Abrir ${app.label}", i); "Toque na notificação para abrir o ${app.label}." }
        }

        if (!granted(ctx, Manifest.permission.READ_CONTACTS)) return "Preciso da permissão de contactos."
        val c = resolveContact(ctx, io, name) ?: return "Não encontrei $name nos contactos."
        if (body.isBlank()) { io.speak("O que quer dizer a ${c.display}?"); body = io.listen().trim() }
        if (body.isBlank()) return "Não ouvi a mensagem."
        io.speak("Vou enviar a ${c.display}: $body. Confirma?")
        if (!isYes(io.listen())) return "Cancelado."
        Memory.lastContact = c.display
        Memory.bumpPriority(ctx, c.display)
        return if (channel == "sms") sendSms(ctx, c, body) else sendWhatsApp(ctx, c, body)
    }

    private fun sendWhatsApp(ctx: Context, c: Contact, body: String): String {
        val pkg = listOf("com.whatsapp", "com.whatsapp.w4b").firstOrNull { Apps.isInstalled(ctx, it) }
            ?: return "O WhatsApp não está instalado."
        val num = waNumber(ctx, c) ?: return "Não consegui obter o número de ${c.display}."
        val i = Intent(Intent.ACTION_VIEW, Uri.parse("https://wa.me/$num?text=" + Uri.encode(body)))
            .setPackage(pkg).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        val auto = HoloAccess.instance != null
        if (auto) HoloAccess.pendingSendUntil = System.currentTimeMillis() + 25000
        return try {
            ctx.startActivity(i)
            if (auto) "A enviar a ${c.display}." else "Abri o WhatsApp com a mensagem escrita. Toque em enviar."
        } catch (e: Exception) {
            HoloAccess.pendingSendUntil = 0L
            notifyOpen(ctx, "WhatsApp: mensagem para ${c.display}", i)
            "O Android não deixou abrir sozinho. Toque na notificação para abrir a conversa."
        }
    }

    private fun waNumber(ctx: Context, c: Contact): String? {
        val raw = (c.normalized ?: c.number).trim()
        var digits = raw.filter { it.isDigit() }
        if (digits.isEmpty()) return null
        if (raw.startsWith("00")) digits = digits.removePrefix("00")
        else if (c.normalized == null && !raw.startsWith("+")) {
            val cc = countryCode(ctx)
            if (cc != null && !digits.startsWith(cc)) digits = cc + digits.trimStart('0')
        }
        return digits
    }

    private fun countryCode(ctx: Context): String? {
        val iso = ctx.getSystemService(TelephonyManager::class.java)?.simCountryIso?.lowercase()
        return when (iso) {
            "ao" -> "244"; "pt" -> "351"; "br" -> "55"; "mz" -> "258"; "cv" -> "238"; "gw" -> "245"; "st" -> "239"
            else -> null
        }
    }

    @SuppressLint("MissingPermission")
    private fun sendSms(ctx: Context, c: Contact, body: String): String {
        if (!granted(ctx, Manifest.permission.SEND_SMS)) return "Preciso da permissão para enviar SMS. Ative-a nas definições do app."
        return try {
            @Suppress("DEPRECATION")
            val sm = if (Build.VERSION.SDK_INT >= 31) ctx.getSystemService(SmsManager::class.java) else SmsManager.getDefault()
            sm.sendMultipartTextMessage(c.number, null, sm.divideMessage(body), null, null)
            "SMS enviado a ${c.display}."
        } catch (e: Exception) {
            "Não consegui enviar o SMS."
        }
    }

    // ------------------------------------------------------------ notas e lembretes

    private fun remind(ctx: Context, t: String): String {
        val r = Reminders.parse(t, System.currentTimeMillis())
            ?: return "Não percebi a hora. Diga, por exemplo: lembra-me de ligar ao João daqui a dez minutos."
        Memory.addNote(ctx, r.first, r.second)
        return "Está bem. Lembrete às " + SimpleDateFormat("HH:mm", pt).format(Date(r.second)) + ": " + r.first + "."
    }

    private fun addNote(ctx: Context, io: Io, t: String): String {
        val key = listOf("tomar nota", "toma nota", "guarda a nota", "nova nota", "take a note", "anota").firstOrNull { t.contains(it) }
            ?: return UNKNOWN
        var body = t.substringAfter(key).trim()
        if (body.startsWith("que ")) body = body.removePrefix("que ").trim()
        if (body.isBlank()) {
            io.speak("O que quer anotar?")
            body = io.listen().trim()
        }
        if (body.isBlank()) return "Não ouvi a nota."
        Memory.addNote(ctx, body, 0L)
        return "Nota guardada."
    }

    private fun readNotes(ctx: Context): String {
        val all = Memory.notes(ctx)
        if (all.isEmpty()) return "Não tem notas nem lembretes."
        val plain = all.filter { it.second == 0L }.map { it.first }
        val rem = all.filter { it.second > 0L }
        val sb = StringBuilder()
        if (plain.isNotEmpty()) sb.append("Tem ${plain.size} nota(s): ").append(plain.takeLast(5).joinToString(". ")).append(". ")
        if (rem.isNotEmpty()) {
            sb.append("Lembretes: ")
            sb.append(rem.joinToString(". ") { it.first + " às " + SimpleDateFormat("HH:mm", pt).format(Date(it.second)) })
        }
        return sb.toString().trim()
    }

    // ------------------------------------------------------------ chamadas e contactos

    private fun cleanName(name: String): String =
        Util.norm(name).split(" ").filter { it.isNotBlank() && it !in stopWords }.joinToString(" ")

    @SuppressLint("MissingPermission")
    private fun call(ctx: Context, io: Io, name: String): String {
        val wanted = cleanName(name)
        if (wanted.isBlank()) return "Não sei a quem ligar. Diga ligar para e o nome."
        if (!granted(ctx, Manifest.permission.READ_CONTACTS)) return "Preciso da permissão de contactos."
        if (!granted(ctx, Manifest.permission.CALL_PHONE)) return "Preciso da permissão para ligar."
        val c = resolveContact(ctx, io, wanted) ?: return "Não encontrei $wanted nos contactos."
        Memory.lastContact = c.display
        val tm = ctx.getSystemService(TelecomManager::class.java)
        tm.placeCall(Uri.fromParts("tel", c.number, null), Bundle())
        return "A ligar para ${c.display}."
    }

    /** Procura o contacto; se não existir, pergunta quem é e aprende o apelido. */
    private fun resolveContact(ctx: Context, io: Io, wanted: String): Contact? {
        var c = findContact(ctx, Memory.aliasOf(ctx, wanted) ?: wanted)
        if (c == null) {
            io.speak("Não encontrei $wanted. Quem é $wanted? Diga o nome do contacto.")
            val real = io.listen()
            if (real.isBlank()) return null
            c = findContact(ctx, real) ?: return null
            Memory.setAlias(ctx, wanted, c.display)
            AppLog.add("Apelido aprendido: $wanted → ${c.display}")
        }
        return c
    }

    /** Escolhe o contacto cujo nome contém todas as palavras ditas (o nome mais curto ganha). */
    private fun findContact(ctx: Context, name: String): Contact? {
        val want = cleanName(name).split(" ").filter { it.isNotBlank() }
        if (want.isEmpty()) return null
        val cols = arrayOf(
            ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME,
            ContactsContract.CommonDataKinds.Phone.NUMBER,
            ContactsContract.CommonDataKinds.Phone.NORMALIZED_NUMBER
        )
        var best: Contact? = null
        ctx.contentResolver.query(ContactsContract.CommonDataKinds.Phone.CONTENT_URI, cols, null, null, null)?.use { c ->
            while (c.moveToNext()) {
                val display = c.getString(0) ?: continue
                val number = c.getString(1) ?: continue
                val n = Util.norm(display)
                val cur = best
                if (want.all { n.contains(it) } && (cur == null || display.length < cur.display.length)) {
                    best = Contact(display, number, c.getString(2))
                }
            }
        }
        return best
    }

    private fun granted(ctx: Context, p: String) =
        ContextCompat.checkSelfPermission(ctx, p) == PackageManager.PERMISSION_GRANTED
}
