package com.holomind.app

import android.Manifest
import android.annotation.SuppressLint
import android.app.PendingIntent
import android.app.RemoteInput
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.hardware.camera2.CameraCharacteristics
import android.hardware.camera2.CameraManager
import android.media.AudioManager
import android.os.BatteryManager
import android.net.Uri
import android.os.Bundle
import android.provider.ContactsContract
import android.telecom.TelecomManager
import androidx.core.content.ContextCompat
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

object Commands {
    class Io(val speak: (String) -> Unit, val listen: () -> String)

    const val UNKNOWN = "Desculpe, ainda não sei fazer isso. Diga ajuda para saber o que posso fazer."

    private val stopWords = setOf("o", "a", "os", "as", "ao", "aos", "para", "pro", "pra", "do", "da", "de", "meu", "minha")
    private val pt = Locale("pt", "PT")

    /** Devolve o que o HoloMind deve dizer (vazio = ficar em silêncio). */
    fun handle(ctx: Context, raw: String, io: Io): String {
        val t = Util.norm(raw)
        return when {
            has(t, "obrigado", "obrigada", "cancelar", "esquece", "deixa") -> ""
            has(t, "ajuda", "o que sabes", "o que sabe", "o que podes", "o que pode") ->
                "Posso ler e responder mensagens, ligar para um contacto, dizer as horas e a bateria, e controlar a lanterna e o volume."
            has(t, "lanterna") -> torch(ctx, !has(t, "apaga", "desliga", "desligar", "fecha"))
            has(t, "bateria") -> battery(ctx)
            has(t, "aumenta o volume", "sobe o volume", "mais volume", "aumentar o volume") -> volume(ctx, true)
            has(t, "baixa o volume", "menos volume", "diminui o volume", "diminuir o volume", "baixar o volume") -> volume(ctx, false)
            has(t, "responde", "responder") -> reply(ctx, io)
            has(t, "mensagem", "mensagens") -> readMessages(io)
            has(t, "liga para ", "ligar para ", "telefona para ") -> call(ctx, t.substringAfter(" para ").trim())
            has(t, "que horas", "horas sao", "a hora") -> "São " + SimpleDateFormat("HH:mm", pt).format(Date())
            has(t, "que dia") -> SimpleDateFormat("EEEE, d 'de' MMMM", pt).format(Date())
            else -> UNKNOWN
        }
    }

    private fun torch(ctx: Context, on: Boolean): String {
        return try {
            val cm = ctx.getSystemService(CameraManager::class.java)
            val id = cm.cameraIdList.firstOrNull {
                cm.getCameraCharacteristics(it).get(CameraCharacteristics.FLASH_INFO_AVAILABLE) == true
            } ?: return "Este telemóvel não tem lanterna."
            cm.setTorchMode(id, on)
            if (on) "Lanterna ligada." else "Lanterna desligada."
        } catch (e: Exception) {
            "Não consegui usar a lanterna."
        }
    }

    private fun battery(ctx: Context): String {
        val bm = ctx.getSystemService(BatteryManager::class.java)
        val pct = bm.getIntProperty(BatteryManager.BATTERY_PROPERTY_CAPACITY)
        return "A bateria está a $pct por cento" + if (bm.isCharging) " e a carregar." else "."
    }

    private fun volume(ctx: Context, up: Boolean): String {
        val am = ctx.getSystemService(AudioManager::class.java)
        am.adjustStreamVolume(
            AudioManager.STREAM_MUSIC,
            if (up) AudioManager.ADJUST_RAISE else AudioManager.ADJUST_LOWER,
            AudioManager.FLAG_SHOW_UI
        )
        return if (up) "Volume aumentado." else "Volume diminuído."
    }

    private fun has(t: String, vararg keys: String) = keys.any { t.contains(it) }

    // ------------------------------------------------------------ mensagens

    private fun readMessages(io: Io): String {
        val msgs = MsgStore.recent(10)
        if (msgs.isEmpty()) return "Não tem mensagens novas."
        val pick = pickSender(io, msgs.map { it.from }.distinct(), "De quem quer ouvir?")
            ?: return "Não percebi o nome."
        return msgs.filter { it.from == pick }.take(3).reversed()
            .joinToString(". ") { "Mensagem de ${it.from}: ${it.text.take(300)}" }
    }

    private fun pickSender(io: Io, senders: List<String>, question: String): String? {
        if (senders.size == 1) return senders[0]
        io.speak("Tem mensagens de ${senders.take(4).joinToString(", ")}. $question")
        val ans = Util.norm(io.listen())
        return senders.firstOrNull { s -> Util.norm(s).split(" ").any { w -> w.length > 2 && ans.contains(w) } }
    }

    /** Responde pela ação de "resposta rápida" da notificação (WhatsApp, SMS, Telegram…), com confirmação. */
    private fun reply(ctx: Context, io: Io): String {
        val withAction = MsgStore.recent(10).filter { it.replyAction != null }
        if (withAction.isEmpty()) return "Não há mensagens para responder."
        val pick = pickSender(io, withAction.map { it.from }.distinct(), "A quem quer responder?")
            ?: return "Não percebi o nome."
        io.speak("O que quer dizer a $pick?")
        val body = io.listen().trim()
        if (body.isBlank()) return "Não ouvi a mensagem."
        io.speak("Vou enviar: $body. Confirma?")
        val ok = Util.norm(io.listen())
        if (!(ok.contains("sim") || ok.contains("confirma") || ok.contains("envia"))) return "Cancelado."
        val m = withAction.first { it.from == pick }
        return if (sendReply(ctx, m, body)) "Mensagem enviada." else "Não consegui enviar."
    }

    private fun sendReply(ctx: Context, m: Msg, text: String): Boolean {
        val a = m.replyAction ?: return false
        val inputs = a.remoteInputs ?: return false
        val intent = Intent()
        val results = Bundle()
        for (ri in inputs) results.putCharSequence(ri.resultKey, text)
        RemoteInput.addResultsToIntent(inputs, intent, results)
        return try { a.actionIntent.send(ctx, 0, intent); true } catch (e: PendingIntent.CanceledException) { false }
    }

    // ------------------------------------------------------------ chamadas

    @SuppressLint("MissingPermission")
    private fun call(ctx: Context, name: String): String {
        if (!granted(ctx, Manifest.permission.READ_CONTACTS)) return "Preciso da permissão de contactos."
        if (!granted(ctx, Manifest.permission.CALL_PHONE)) return "Preciso da permissão para ligar."
        val (display, number) = findContact(ctx, name) ?: return "Não encontrei $name nos contactos."
        val tm = ctx.getSystemService(TelecomManager::class.java)
        tm.placeCall(Uri.fromParts("tel", number, null), Bundle())
        return "A ligar para $display."
    }

    /** Escolhe o contacto cujo nome contém todas as palavras ditas (o nome mais curto ganha). */
    private fun findContact(ctx: Context, name: String): Pair<String, String>? {
        val want = Util.norm(name).split(" ").filter { it.isNotBlank() && it !in stopWords }
        if (want.isEmpty()) return null
        val cols = arrayOf(
            ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME,
            ContactsContract.CommonDataKinds.Phone.NUMBER
        )
        var best: Pair<String, String>? = null
        ctx.contentResolver.query(ContactsContract.CommonDataKinds.Phone.CONTENT_URI, cols, null, null, null)?.use { c ->
            while (c.moveToNext()) {
                val display = c.getString(0) ?: continue
                val number = c.getString(1) ?: continue
                val n = Util.norm(display)
                if (want.all { n.contains(it) } && (best == null || display.length < best!!.first.length)) {
                    best = display to number
                }
            }
        }
        return best
    }

    private fun granted(ctx: Context, p: String) =
        ContextCompat.checkSelfPermission(ctx, p) == PackageManager.PERMISSION_GRANTED
}
