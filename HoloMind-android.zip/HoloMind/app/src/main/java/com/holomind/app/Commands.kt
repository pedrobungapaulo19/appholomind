package com.holomind.app

import android.Manifest
import android.annotation.SuppressLint
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.RemoteInput
import android.content.ActivityNotFoundException
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.hardware.camera2.CameraCharacteristics
import android.hardware.camera2.CameraManager
import android.media.AudioManager
import android.net.Uri
import android.os.BatteryManager
import android.os.Build
import android.os.Bundle
import android.provider.ContactsContract
import android.provider.MediaStore
import android.provider.Settings
import android.telecom.TelecomManager
import android.telephony.SmsManager
import android.telephony.TelephonyManager
import androidx.core.app.NotificationCompat
import androidx.core.content.ContextCompat
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

/** Executa os pedidos percebidos pelo [Nlu] (português e inglês). */
object Commands {
    class Io(val speak: (String) -> Unit, val listen: () -> String)
    data class Contact(val display: String, val number: String, val normalized: String?)

    const val UNKNOWN = "Desculpe, ainda não sei fazer isso. Diga ajuda para saber o que posso fazer."

    private val stopWords = setOf("o", "a", "os", "as", "ao", "aos", "para", "pro", "pra", "do", "da", "de", "meu", "minha", "to", "the")
    private val pt = Locale("pt", "PT")

    fun understands(ctx: Context, raw: String): Boolean =
        Memory.customAction(ctx, Util.norm(raw)) != null || Nlu.parse(raw).isNotEmpty()

    /** Devolve o que o HoloMind deve dizer (vazio = ficar em silêncio). Pedidos encadeados são feitos por ordem. */
    fun handle(ctx: Context, raw: String, io: Io): String {
        val t = Util.norm(raw)
        if (t.isBlank()) return ""
        Memory.customAction(ctx, t)?.let { return run(ctx, it, io) }
        val cmds = Nlu.parse(raw)
        if (cmds.isEmpty()) return UNKNOWN
        val said = ArrayList<String>()
        for (c in cmds) {
            if (c.name == "FIM") break
            val r = execute(ctx, c, io)
            if (r.isNotBlank() && r != UNKNOWN) said.add(r)
        }
        return said.joinToString(" ")
    }

    private fun execute(ctx: Context, c: Nlu.Cmd, io: Io): String = when (c.name) {
        "TIME" -> run(ctx, "hora", io)
        "DATE" -> run(ctx, "dia", io)
        "BATTERY" -> run(ctx, "bateria", io)
        "FLASH_ON" -> run(ctx, "lanterna_on", io)
        "FLASH_OFF" -> run(ctx, "lanterna_off", io)
        "VOLUME_UP" -> run(ctx, "volume_up", io)
        "VOLUME_DOWN" -> run(ctx, "volume_down", io)
        "HELP" -> run(ctx, "ajuda", io)
        "ROUTINE" -> run(ctx, "rotina", io)
        "NEXT" -> run(ctx, "proxima", io)
        "READ" -> run(ctx, "mensagens", io)
        "OPEN" -> openTarget(ctx, c.arg)
        "CHAT" -> chat(ctx, io, c.arg)
        "CALL" -> call(ctx, io, if (c.last) (Memory.lastContact ?: "") else c.arg)
        "REPLY" -> replyTo(ctx, io, c)
        "SEND" -> sendTo(ctx, io, c)
        "REMIND" -> remind(ctx, c.raw)
        "NOTE_ADD" -> addNote(ctx, io, c.raw)
        "NOTE_READ" -> readNotes(ctx)
        "NOTE_CLEAR" -> { Memory.clearNotes(ctx); "Notas apagadas." }
        else -> UNKNOWN
    }

    /** Pedidos simples que podem ser aprendidos como "frase nova". */
    fun learnableKey(t: String): String? {
        val c = Nlu.parse(t).firstOrNull() ?: return null
        return when (c.name) {
            "TIME" -> "hora"; "DATE" -> "dia"; "BATTERY" -> "bateria"
            "FLASH_ON" -> "lanterna_on"; "FLASH_OFF" -> "lanterna_off"
            "VOLUME_UP" -> "volume_up"; "VOLUME_DOWN" -> "volume_down"
            "READ" -> "mensagens"; "HELP" -> "ajuda"; "ROUTINE" -> "rotina"; "NEXT" -> "proxima"
            else -> null
        }
    }

    fun run(ctx: Context, key: String, io: Io): String = when (key) {
        "fim" -> ""
        "ajuda" -> "Posso ler e responder mensagens, enviar mensagens pelo WhatsApp ou SMS, abrir aplicações e contactos, ligar para contactos, guardar notas e lembretes, dizer as horas e a bateria, e controlar a lanterna e o volume. Pode encadear pedidos, falar em português ou inglês, e eu aprendo frases novas."
        "rotina" -> routine(ctx)
        "proxima" -> readNext(ctx)
        "mensagens" -> readMessages(ctx, io)
        "lanterna_on" -> torch(ctx, true)
        "lanterna_off" -> torch(ctx, false)
        "bateria" -> battery(ctx)
        "volume_up" -> volume(ctx, true)
        "volume_down" -> volume(ctx, false)
        "hora" -> "São " + SimpleDateFormat("HH:mm", pt).format(Date())
        "dia" -> SimpleDateFormat("EEEE, d 'de' MMMM", pt).format(Date())
        else -> UNKNOWN
    }

    // ------------------------------------------------------------ sistema

    private fun torch(ctx: Context, on: Boolean): String {
        return try {
            val cm = ctx.getSystemService(CameraManager::class.java)
            val id = cm.cameraIdList.firstOrNull {
                cm.getCameraCharacteristics(it).get(CameraCharacteristics.FLASH_INFO_AVAILABLE) == true
            } ?: return "Este telemóvel não tem lanterna."
            cm.setTorchMode(id, on)
            if (on) "Lanterna ligada." else "Lanterna desligada."
        } catch (e: Exception) {
            "Não consegui usar a lanterna."
        }
    }

    private fun battery(ctx: Context): String {
        val bm = ctx.getSystemService(BatteryManager::class.java)
        val pct = bm.getIntProperty(BatteryManager.BATTERY_PROPERTY_CAPACITY)
        return "A bateria está a $pct por cento" + if (bm.isCharging) " e a carregar." else "."
    }

    private fun volume(ctx: Context, up: Boolean): String {
        val am = ctx.getSystemService(AudioManager::class.java)
        am.adjustStreamVolume(
            AudioManager.STREAM_MUSIC,
            if (up) AudioManager.ADJUST_RAISE else AudioManager.ADJUST_LOWER,
            AudioManager.FLAG_SHOW_UI
        )
        return if (up) "Volume aumentado." else "Volume diminuído."
    }

    /** "Bom dia": cumprimento + horas + bateria + resumo das mensagens. */
    private fun routine(ctx: Context): String {
        refreshMsgs()
        val h = Calendar.getInstance().get(Calendar.HOUR_OF_DAY)
        val saud = if (h in 5..11) "Bom dia" else if (h in 12..18) "Boa tarde" else "Boa noite"
        val name = Prefs(ctx).userName
        val sb = StringBuilder(saud)
        if (name.isNotBlank()) sb.append(", ").append(name)
        sb.append(". São ").append(SimpleDateFormat("HH:mm", pt).format(Date())).append(". ")
        sb.append(battery(ctx)).append(" ")
        val senders = orderedSenders(ctx, MsgStore.recent(30))
        if (senders.isEmpty()) sb.append("Não tem mensagens novas.")
        else sb.append("Tem mensagens de ").append(senders.take(4).joinToString(", ")).append(".")
        return sb.toString()
    }

    // ------------------------------------------------------------ abrir aplicações, contactos e definições

    private fun openTarget(ctx: Context, arg: String): String = when {
        arg == "contacts" -> launchSystem(ctx, Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_APP_CONTACTS), "os contactos")
        arg == "messages" -> launchSystem(ctx, Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_APP_MESSAGING), "as mensagens")
        arg == "dialer" -> launchSystem(ctx, Intent(Intent.ACTION_DIAL), "o telefone")
        arg == "settings" -> launchSystem(ctx, Intent(Settings.ACTION_SETTINGS), "as definições")
        arg == "camera" -> launchSystem(ctx, Intent(MediaStore.INTENT_ACTION_STILL_IMAGE_CAMERA), "a câmara")
        arg.startsWith("app:") -> openApp(ctx, arg.removePrefix("app:"))
        else -> UNKNOWN
    }

    private fun launchSystem(ctx: Context, i: Intent, what: String): String {
        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        return try {
            ctx.startActivity(i)
            "A abrir $what."
        } catch (e: ActivityNotFoundException) {
            "Não encontrei $what neste telemóvel."
        } catch (e: Exception) {
            notifyOpen(ctx, "Abrir $what", i)
            "O Android não deixou abrir sozinho. Toque na notificação para abrir $what."
        }
    }

    private fun openApp(ctx: Context, name: String): String {
        val app = Apps.find(ctx, name) ?: return "Não encontrei a aplicação $name."
        val i = Apps.launchIntent(ctx, app.pkg) ?: return "Não consegui abrir ${app.label}."
        return try {
            ctx.startActivity(i)
            "A abrir ${app.label}."
        } catch (e: Exception) {
            notifyOpen(ctx, "Abrir ${app.label}", i)
            "O Android não deixou abrir sozinho. Toque na notificação para abrir ${app.label}."
        }
    }

    /** Plano B quando o Android bloqueia abrir uma app em segundo plano: notificação com toque para abrir. */
    private fun notifyOpen(ctx: Context, title: String, intent: Intent) {
        val nm = ctx.getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel("holomind_open", "Abrir aplicações", NotificationManager.IMPORTANCE_HIGH))
        val pi = PendingIntent.getActivity(ctx, 7, intent, PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)
        nm.notify(
            3,
            NotificationCompat.Builder(ctx, "holomind_open")
                .setSmallIcon(android.R.drawable.ic_btn_speak_now)
                .setContentTitle(title)
                .setContentText("Toque para abrir")
                .setContentIntent(pi).setAutoCancel(true).build()
        )
    }

    // ------------------------------------------------------------ ler e responder mensagens

    /** Atualiza a lista com o que já está na barra de notificações. */
    private fun refreshMsgs() { MsgNotificationListener.instance?.refreshActive() }

    private fun orderedSenders(ctx: Context, msgs: List<Msg>): List<String> =
        msgs.map { it.from }.distinct().sortedByDescending { Memory.priorityScore(ctx, it) }

    private fun matchSender(senders: List<String>, name: String): String? {
        val n = Util.norm(name)
        if (n.isBlank()) return null
        return senders.firstOrNull { f ->
            val fn = Util.norm(f)
            fn.contains(n) || n.split(" ").any { w -> w.length > 1 && fn.split(" ").contains(w) }
        }
    }

    private fun readMessages(ctx: Context, io: Io): String {
        refreshMsgs()
        val msgs = MsgStore.recent(10)
        if (msgs.isEmpty()) return "Não tem mensagens novas na barra de notificações."
        Memory.readSenders.clear()
        val pick = pickSender(io, orderedSenders(ctx, msgs), "De quem quer ouvir?") ?: return "Não percebi o nome."
        return readFrom(pick, msgs)
    }

    private fun readNext(ctx: Context): String {
        refreshMsgs()
        val msgs = MsgStore.recent(10)
        if (msgs.isEmpty()) return "Não tem mensagens novas."
        val next = orderedSenders(ctx, msgs).firstOrNull { it !in Memory.readSenders }
            ?: return "Não há mais mensagens."
        return readFrom(next, msgs)
    }

    // Cada mensagem numa frase própria: assim o idioma (português/inglês) é detetado frase a frase ao falar.
    private fun readFrom(sender: String, msgs: List<Msg>): String {
        Memory.lastContact = sender
        Memory.readSenders.add(sender)
        return msgs.filter { it.from == sender }.take(3).reversed()
            .joinToString(". ") { "Mensagem de ${it.from}. ${it.text.take(300)}" }
    }

    private fun pickSender(io: Io, senders: List<String>, question: String): String? {
        if (senders.size == 1) return senders[0]
        io.speak("Tem mensagens de ${senders.take(4).joinToString(", ")}. $question")
        val ans = Util.norm(io.listen())
        return senders.firstOrNull { s -> Util.norm(s).split(" ").any { w -> w.length > 2 && ans.contains(w) } }
    }

    /** "Entra na mensagem do João": lê as mensagens dele; se não houver, abre a conversa no WhatsApp. */
    private fun chat(ctx: Context, io: Io, name: String): String {
        refreshMsgs()
        val msgs = MsgStore.recent(30)
        val from = matchSender(msgs.map { it.from }.distinct(), name)
        if (from != null) return readFrom(from, msgs)
        if (!granted(ctx, Manifest.permission.READ_CONTACTS)) return "Preciso da permissão de contactos."
        val c = resolveContact(ctx, io, cleanName(name)) ?: return "Não encontrei $name."
        Memory.lastContact = c.display
        return openWhatsAppChat(ctx, c, "")
    }

    /** Responde pela ação de "resposta rápida" da notificação (WhatsApp, SMS, Telegram…), com confirmação. */
    private fun replyTo(ctx: Context, io: Io, cmd: Nlu.Cmd): String {
        refreshMsgs()
        val withAction = MsgStore.recent(10).filter { it.replyAction != null }
        if (withAction.isEmpty()) return "Não há mensagens para responder."
        val senders = withAction.map { it.from }.distinct()
        val last = Memory.lastContact
        val named = matchSender(senders, cmd.arg)
        val pick: String? = when {
            named != null -> named
            cmd.last && last != null && last in senders -> last
            senders.size == 1 -> senders[0]
            else -> pickSender(io, orderedSenders(ctx, withAction), "A quem quer responder?")
        }
        if (pick == null) return "Não percebi o nome."
        var body = cmd.body.trim()
        if (body.isBlank()) {
            io.speak("O que quer dizer a $pick?")
            body = io.listen().trim()
        }
        if (body.isBlank()) return "Não ouvi a mensagem."
        io.speak("Vou enviar: $body. Confirma?")
        if (!isYes(io.listen())) return "Cancelado."
        val m = withAction.first { it.from == pick }
        if (!sendReply(ctx, m, body)) return "Não consegui enviar."
        Memory.bumpPriority(ctx, pick)
        Memory.lastContact = pick
        return "Mensagem enviada."
    }

    private fun isYes(raw: String): Boolean {
        val ok = Util.norm(raw)
        return ok.contains("sim") || ok.contains("confirma") || ok.contains("envia") || ok.contains("yes") ||
            ok.contains("send") || ok.contains("ok")
    }

    private fun sendReply(ctx: Context, m: Msg, text: String): Boolean {
        val a = m.replyAction ?: return false
        val inputs = a.remoteInputs ?: return false
        val intent = Intent()
        val results = Bundle()
        for (ri in inputs) results.putCharSequence(ri.resultKey, text)
        RemoteInput.addResultsToIntent(inputs, intent, results)
        return try { a.actionIntent.send(ctx, 0, intent); true } catch (e: PendingIntent.CanceledException) { false }
    }

    // ------------------------------------------------------------ enviar mensagens novas (WhatsApp / SMS)

    private fun sendTo(ctx: Context, io: Io, cmd: Nlu.Cmd): String {
        val channel = if (cmd.channel.isBlank()) "wa" else cmd.channel
        var name = cleanName(cmd.arg)
        if (name.isBlank()) { io.speak("Para quem?"); name = cleanName(io.listen()) }
        if (name.isBlank()) return "Não percebi para quem."

        if (channel == "fb") {
            val app = Apps.find(ctx, "messenger") ?: Apps.find(ctx, "facebook") ?: return "Não encontrei o Messenger."
            val i = Apps.launchIntent(ctx, app.pkg) ?: return "Não consegui abrir o Messenger."
            return try {
                ctx.startActivity(i)
                "Ainda não consigo enviar pelo Facebook. Abri o ${app.label} para si."
            } catch (e: Exception) { notifyOpen(ctx, "Abrir ${app.label}", i); "Toque na notificação para abrir o ${app.label}." }
        }

        if (!granted(ctx, Manifest.permission.READ_CONTACTS)) return "Preciso da permissão de contactos."
        val c = resolveContact(ctx, io, name) ?: return "Não encontrei $name nos contactos."
        var body = cmd.body.trim()
        if (body.isBlank()) { io.speak("O que quer dizer a ${c.display}?"); body = io.listen().trim() }
        if (body.isBlank()) return "Não ouvi a mensagem."
        io.speak("Vou enviar a ${c.display}: $body. Confirma?")
        if (!isYes(io.listen())) return "Cancelado."
        Memory.lastContact = c.display
        Memory.bumpPriority(ctx, c.display)
        return if (channel == "sms") sendSms(ctx, c, body) else openWhatsAppChat(ctx, c, body)
    }

    /** Abre a conversa no WhatsApp (com o texto escrito, se houver) e, com a acessibilidade ligada, carrega em Enviar. */
    private fun openWhatsAppChat(ctx: Context, c: Contact, body: String): String {
        val pkg = listOf("com.whatsapp", "com.whatsapp.w4b").firstOrNull { Apps.isInstalled(ctx, it) }
            ?: return "O WhatsApp não está instalado."
        val num = waNumber(ctx, c) ?: return "Não consegui obter o número de ${c.display}."
        val url = if (body.isBlank()) "https://wa.me/$num" else "https://wa.me/$num?text=" + Uri.encode(body)
        val i = Intent(Intent.ACTION_VIEW, Uri.parse(url)).setPackage(pkg).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        val auto = body.isNotBlank() && HoloAccess.instance != null
        if (auto) HoloAccess.pendingSendUntil = System.currentTimeMillis() + 25000
        return try {
            ctx.startActivity(i)
            when {
                body.isBlank() -> "A abrir a conversa com ${c.display}."
                auto -> "A enviar a ${c.display}."
                else -> "Abri o WhatsApp com a mensagem escrita. Toque em enviar."
            }
        } catch (e: Exception) {
            HoloAccess.pendingSendUntil = 0L
            notifyOpen(ctx, "WhatsApp: ${c.display}", i)
            "O Android não deixou abrir sozinho. Toque na notificação para abrir a conversa."
        }
    }

    private fun waNumber(ctx: Context, c: Contact): String? {
        val raw = (c.normalized ?: c.number).trim()
        var digits = raw.filter { it.isDigit() }
        if (digits.isEmpty()) return null
        if (raw.startsWith("00")) digits = digits.removePrefix("00")
        else if (c.normalized == null && !raw.startsWith("+")) {
            val cc = countryCode(ctx)
            if (cc != null && !digits.startsWith(cc)) digits = cc + digits.trimStart('0')
        }
        return digits
    }

    private fun countryCode(ctx: Context): String? {
        val iso = ctx.getSystemService(TelephonyManager::class.java)?.simCountryIso?.lowercase()
        return when (iso) {
            "ao" -> "244"; "pt" -> "351"; "br" -> "55"; "mz" -> "258"; "cv" -> "238"; "gw" -> "245"; "st" -> "239"
            else -> null
        }
    }

    @SuppressLint("MissingPermission")
    private fun sendSms(ctx: Context, c: Contact, body: String): String {
        if (!granted(ctx, Manifest.permission.SEND_SMS)) return "Preciso da permissão para enviar SMS. Ative-a nas definições do app."
        return try {
            @Suppress("DEPRECATION")
            val sm = if (Build.VERSION.SDK_INT >= 31) ctx.getSystemService(SmsManager::class.java) else SmsManager.getDefault()
            sm.sendMultipartTextMessage(c.number, null, sm.divideMessage(body), null, null)
            "SMS enviado a ${c.display}."
        } catch (e: Exception) {
            "Não consegui enviar o SMS."
        }
    }

    // ------------------------------------------------------------ notas e lembretes

    private fun remind(ctx: Context, t: String): String {
        val r = Reminders.parse(t, System.currentTimeMillis())
            ?: return "Não percebi a hora. Diga, por exemplo: lembra-me de ligar ao João daqui a dez minutos."
        Memory.addNote(ctx, r.first, r.second)
        return "Está bem. Lembrete às " + SimpleDateFormat("HH:mm", pt).format(Date(r.second)) + ": " + r.first + "."
    }

    private fun addNote(ctx: Context, io: Io, t: String): String {
        val key = listOf("tomar nota", "toma nota", "guarda a nota", "nova nota", "take a note", "anota").firstOrNull { t.contains(it) }
            ?: return UNKNOWN
        var body = t.substringAfter(key).trim()
        if (body.startsWith("que ")) body = body.removePrefix("que ").trim()
        if (body.isBlank()) {
            io.speak("O que quer anotar?")
            body = io.listen().trim()
        }
        if (body.isBlank()) return "Não ouvi a nota."
        Memory.addNote(ctx, body, 0L)
        return "Nota guardada."
    }

    private fun readNotes(ctx: Context): String {
        val all = Memory.notes(ctx)
        if (all.isEmpty()) return "Não tem notas nem lembretes."
        val plain = all.filter { it.second == 0L }.map { it.first }
        val rem = all.filter { it.second > 0L }
        val sb = StringBuilder()
        if (plain.isNotEmpty()) sb.append("Tem ${plain.size} nota(s): ").append(plain.takeLast(5).joinToString(". ")).append(". ")
        if (rem.isNotEmpty()) {
            sb.append("Lembretes: ")
            sb.append(rem.joinToString(". ") { it.first + " às " + SimpleDateFormat("HH:mm", pt).format(Date(it.second)) })
        }
        return sb.toString().trim()
    }

    // ------------------------------------------------------------ chamadas e contactos

    private fun cleanName(name: String): String =
        Util.norm(name).split(" ").filter { it.isNotBlank() && it !in stopWords }.joinToString(" ")

    @SuppressLint("MissingPermission")
    private fun call(ctx: Context, io: Io, name: String): String {
        val wanted = cleanName(name)
        if (wanted.isBlank()) return "Não sei a quem ligar. Diga ligar para e o nome."
        if (!granted(ctx, Manifest.permission.READ_CONTACTS)) return "Preciso da permissão de contactos."
        if (!granted(ctx, Manifest.permission.CALL_PHONE)) return "Preciso da permissão para ligar."
        val c = resolveContact(ctx, io, wanted) ?: return "Não encontrei $wanted nos contactos."
        Memory.lastContact = c.display
        val tm = ctx.getSystemService(TelecomManager::class.java)
        tm.placeCall(Uri.fromParts("tel", c.number, null), Bundle())
        return "A ligar para ${c.display}."
    }

    /** Procura o contacto; se não existir, pergunta quem é e aprende o apelido. */
    private fun resolveContact(ctx: Context, io: Io, wanted: String): Contact? {
        var c = findContact(ctx, Memory.aliasOf(ctx, wanted) ?: wanted)
        if (c == null) {
            io.speak("Não encontrei $wanted. Quem é $wanted? Diga o nome do contacto.")
            val real = io.listen()
            if (real.isBlank()) return null
            c = findContact(ctx, real) ?: return null
            Memory.setAlias(ctx, wanted, c.display)
            AppLog.add("Apelido aprendido: $wanted → ${c.display}")
        }
        return c
    }

    /** Escolhe o contacto cujo nome contém todas as palavras ditas (o nome mais curto ganha). */
    private fun findContact(ctx: Context, name: String): Contact? {
        val want = cleanName(name).split(" ").filter { it.isNotBlank() }
        if (want.isEmpty()) return null
        val cols = arrayOf(
            ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME,
            ContactsContract.CommonDataKinds.Phone.NUMBER,
            ContactsContract.CommonDataKinds.Phone.NORMALIZED_NUMBER
        )
        var best: Contact? = null
        ctx.contentResolver.query(ContactsContract.CommonDataKinds.Phone.CONTENT_URI, cols, null, null, null)?.use { c ->
            while (c.moveToNext()) {
                val display = c.getString(0) ?: continue
                val number = c.getString(1) ?: continue
                val n = Util.norm(display)
                val cur = best
                if (want.all { n.contains(it) } && (cur == null || display.length < cur.display.length)) {
                    best = Contact(display, number, c.getString(2))
                }
            }
        }
        return best
    }

    private fun granted(ctx: Context, p: String) =
        ContextCompat.checkSelfPermission(ctx, p) == PackageManager.PERMISSION_GRANTED
}
