package com.holomind.app

import android.app.Notification
import android.content.Intent
import androidx.core.content.ContextCompat
import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification

data class Msg(
    val app: String, val from: String, val text: String, val time: Long,
    val replyAction: Notification.Action? = null
)

object MsgStore {
    private val items = ArrayList<Msg>()

    @Synchronized fun add(m: Msg) {
        items.add(m)
        while (items.size > 30) items.removeAt(0)
    }

    @Synchronized fun recent(n: Int): List<Msg> = items.takeLast(n).reversed()

    @Synchronized fun clearFrom(sender: String) { items.removeAll { it.from == sender } }
}

class MsgNotificationListener : NotificationListenerService() {
    private val known = setOf(
        "com.whatsapp", "com.whatsapp.w4b", "org.telegram.messenger",
        "com.google.android.apps.messaging", "com.samsung.android.messaging",
        "com.facebook.orca", "com.android.mms"
    )

    /** O Android liga este serviço sozinho no arranque: aproveitamos para (re)ativar a escuta. */
    override fun onListenerConnected() {
        if (Prefs(this).serviceEnabled && !ListenService.isRunning) {
            try {
                ContextCompat.startForegroundService(this, Intent(this, ListenService::class.java))
                AppLog.add("Escuta reativada automaticamente")
            } catch (e: Exception) {
                AppLog.add("Não foi possível reativar sozinho: ${e.javaClass.simpleName}")
            }
        }
    }

    override fun onNotificationPosted(sbn: StatusBarNotification) {
        val n = sbn.notification ?: return
        if (n.flags and Notification.FLAG_GROUP_SUMMARY != 0) return
        if (n.category != Notification.CATEGORY_MESSAGE && sbn.packageName !in known) return
        val title = n.extras.getCharSequence(Notification.EXTRA_TITLE)?.toString() ?: return
        val text = n.extras.getCharSequence(Notification.EXTRA_TEXT)?.toString() ?: return
        val reply = n.actions?.firstOrNull { a -> !a.remoteInputs.isNullOrEmpty() }
        MsgStore.add(Msg(sbn.packageName, title, text, sbn.postTime, reply))
    }
}
