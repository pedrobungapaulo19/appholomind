package com.holomind.app

import android.app.Notification
import android.content.Intent
import android.media.AudioDeviceInfo
import android.media.AudioManager
import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification
import androidx.core.content.ContextCompat

data class Msg(
    val app: String, val from: String, val text: String, val time: Long,
    val replyAction: Notification.Action? = null
)

object MsgStore {
    private val items = ArrayList<Msg>()

    @Synchronized fun add(m: Msg) {
        items.add(m)
        while (items.size > 30) items.removeAt(0)
    }

    @Synchronized fun recent(n: Int): List<Msg> = items.takeLast(n).reversed()

    @Synchronized fun clearFrom(sender: String) { items.removeAll { it.from == sender } }
}

class MsgNotificationListener : NotificationListenerService() {
    private var lastAnnounce = 0L

    private val known = setOf(
        "com.whatsapp", "com.whatsapp.w4b", "org.telegram.messenger",
        "com.google.android.apps.messaging", "com.samsung.android.messaging",
        "com.facebook.orca", "com.android.mms"
    )

    /** O Android liga este serviço sozinho no arranque: aproveitamos para (re)ativar a escuta. */
    override fun onListenerConnected() {
        if (Prefs(this).serviceEnabled && !ListenService.isRunning) {
            try {
                ContextCompat.startForegroundService(this, Intent(this, ListenService::class.java))
                AppLog.add("Escuta reativada automaticamente")
            } catch (e: Exception) {
                AppLog.add("Não foi possível reativar sozinho: ${e.javaClass.simpleName}")
            }
        }
    }

    override fun onNotificationPosted(sbn: StatusBarNotification) {
        val n = sbn.notification ?: return
        if ((n.flags and Notification.FLAG_GROUP_SUMMARY) != 0) return
        if (n.category != Notification.CATEGORY_MESSAGE && sbn.packageName !in known) return
        val title = n.extras.getCharSequence(Notification.EXTRA_TITLE)?.toString() ?: return
        val text = n.extras.getCharSequence(Notification.EXTRA_TEXT)?.toString() ?: return
        val reply = n.actions?.firstOrNull { a -> !a.remoteInputs.isNullOrEmpty() }
        MsgStore.add(Msg(sbn.packageName, title, text, sbn.postTime, reply))
        maybeAnnounce(title)
    }

    /** Modo condução: com auscultadores/Bluetooth ligados, avisa por voz que chegou uma mensagem. */
    private fun maybeAnnounce(from: String) {
        val prefs = Prefs(this)
        if (!prefs.driveMode || !ListenService.isRunning) return
        val now = System.currentTimeMillis()
        if (now - lastAnnounce < 20000 || !headsetConnected()) return
        lastAnnounce = now
        val call = prefs.wakeName.replace("HoloMind", "Holomaind")
        ListenService.announce("Tem uma mensagem de $from. Diga $call e depois ler mensagens.")
    }

    private fun headsetConnected(): Boolean {
        val am = getSystemService(AudioManager::class.java)
        return am.getDevices(AudioManager.GET_DEVICES_OUTPUTS).any {
            it.type == AudioDeviceInfo.TYPE_BLUETOOTH_A2DP || it.type == AudioDeviceInfo.TYPE_BLUETOOTH_SCO ||
                it.type == AudioDeviceInfo.TYPE_WIRED_HEADSET || it.type == AudioDeviceInfo.TYPE_WIRED_HEADPHONES ||
                it.type == AudioDeviceInfo.TYPE_USB_HEADSET
        }
    }
}
