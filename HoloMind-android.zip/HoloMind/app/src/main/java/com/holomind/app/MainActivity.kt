package com.holomind.app

import android.Manifest
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.PowerManager
import android.provider.Settings
import android.speech.tts.TextToSpeech
import android.webkit.JavascriptInterface
import android.webkit.WebResourceRequest
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.result.contract.ActivityResultContracts
import androidx.core.app.NotificationManagerCompat
import androidx.core.content.ContextCompat
import org.json.JSONArray
import org.json.JSONObject
import java.util.Locale

class MainActivity : ComponentActivity() {
    private lateinit var web: WebView
    private lateinit var prefs: Prefs
    private var testTts: TextToSpeech? = null

    private val permLauncher =
        registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { refreshUi() }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        prefs = Prefs(this)
        web = WebView(this)
        setContentView(web)
        web.settings.javaScriptEnabled = true
        // A interface é local: bloqueia qualquer navegação para fora
        web.webViewClient = object : WebViewClient() {
            override fun shouldOverrideUrlLoading(view: WebView, request: WebResourceRequest) = true
        }
        web.addJavascriptInterface(Bridge(), "Android")
        web.loadUrl("file:///android_asset/www/index.html")
        if (intent.getBooleanExtra("autostart", false)) startListen()
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        if (intent.getBooleanExtra("autostart", false)) startListen()
    }

    override fun onResume() { super.onResume(); refreshUi() }

    override fun onDestroy() {
        testTts?.shutdown()
        super.onDestroy()
    }

    private fun refreshUi() {
        if (::web.isInitialized) web.post { web.evaluateJavascript("if(window.refresh)refresh()", null) }
    }

    private fun granted(p: String) =
        ContextCompat.checkSelfPermission(this, p) == PackageManager.PERMISSION_GRANTED

    private fun wantedPerms(): Array<String> {
        val l = mutableListOf(
            Manifest.permission.RECORD_AUDIO,
            Manifest.permission.READ_CONTACTS,
            Manifest.permission.CALL_PHONE
        )
        if (Build.VERSION.SDK_INT >= 33) l.add(Manifest.permission.POST_NOTIFICATIONS)
        return l.toTypedArray()
    }

    private fun startListen() {
        if (!granted(Manifest.permission.RECORD_AUDIO)) { permLauncher.launch(wantedPerms()); return }
        prefs.serviceEnabled = true
        ContextCompat.startForegroundService(this, Intent(this, ListenService::class.java))
        web.postDelayed({ refreshUi() }, 800)
    }

    private fun stopListen() {
        prefs.serviceEnabled = false
        stopService(Intent(this, ListenService::class.java))
        web.postDelayed({ refreshUi() }, 500)
    }

    inner class Bridge {
        @JavascriptInterface fun getState(): String {
            val o = JSONObject()
            o.put("mic", granted(Manifest.permission.RECORD_AUDIO))
            o.put("contacts", granted(Manifest.permission.READ_CONTACTS))
            o.put("call", granted(Manifest.permission.CALL_PHONE))
            o.put("notif", Build.VERSION.SDK_INT < 33 || granted(Manifest.permission.POST_NOTIFICATIONS))
            o.put("notifAccess", NotificationManagerCompat.getEnabledListenerPackages(this@MainActivity).contains(packageName))
            o.put("battery", getSystemService(PowerManager::class.java).isIgnoringBatteryOptimizations(packageName))
            o.put("model", ModelHelper.hasModel(this@MainActivity))
            o.put("running", ListenService.isRunning)
            o.put("version", try { packageManager.getPackageInfo(packageName, 0).versionName } catch (e: Exception) { "" })
            o.put("settings", prefs.toJson())
            return o.toString()
        }

        /** Estado leve, lido várias vezes por segundo pela interface. */
        @JavascriptInterface fun getLive(): String = JSONObject()
            .put("running", ListenService.isRunning)
            .put("level", ListenService.level)
            .put("status", ListenService.status)
            .put("log", JSONArray(AppLog.recent(12)))
            .toString()

        @JavascriptInterface fun save(json: String) {
            try { prefs.fromJson(JSONObject(json)) } catch (e: Exception) { AppLog.add("Configuração inválida: ${e.message}") }
        }

        @JavascriptInterface fun requestPerms() { runOnUiThread { permLauncher.launch(wantedPerms()) } }
        @JavascriptInterface fun toggle() { runOnUiThread { if (ListenService.isRunning) stopListen() else startListen() } }

        @JavascriptInterface fun openNotificationAccess() {
            runOnUiThread { startActivity(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS)) }
        }

        @JavascriptInterface fun ignoreBattery() {
            runOnUiThread {
                startActivity(Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS, Uri.parse("package:$packageName")))
            }
        }

        @JavascriptInterface fun openAppSettings() {
            runOnUiThread {
                startActivity(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:$packageName")))
            }
        }

        @JavascriptInterface fun copyLog() {
            runOnUiThread {
                val cm = getSystemService(ClipboardManager::class.java)
                cm.setPrimaryClip(ClipData.newPlainText("HoloMind", AppLog.all()))
                Toast.makeText(this@MainActivity, "Registo copiado", Toast.LENGTH_SHORT).show()
            }
        }

        @JavascriptInterface fun testSpeak() {
            runOnUiThread {
                testTts?.shutdown()
                val name = prefs.userName
                testTts = TextToSpeech(this@MainActivity) { st ->
                    if (st == TextToSpeech.SUCCESS) {
                        testTts?.setLanguage(Locale("pt", "PT"))
                        testTts?.speak(
                            if (name.isBlank()) "Olá! Eu sou o HoloMind." else "Olá, $name! Eu sou o HoloMind.",
                            TextToSpeech.QUEUE_FLUSH, null, "teste"
                        )
                    } else Toast.makeText(this@MainActivity, "Voz indisponível neste telemóvel", Toast.LENGTH_LONG).show()
                }
            }
        }
    }
}
