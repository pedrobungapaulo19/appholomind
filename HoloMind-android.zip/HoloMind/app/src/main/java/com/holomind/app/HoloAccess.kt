package com.holomind.app

import android.accessibilityservice.AccessibilityService
import android.content.Intent
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo

/**
 * Serviço de acessibilidade MUITO limitado: só observa o WhatsApp e, quando o HoloMind acabou de abrir uma
 * conversa com a mensagem escrita, carrega no botão "Enviar". Não lê nem guarda nada.
 */
class HoloAccess : AccessibilityService() {
    companion object {
        @Volatile var instance: HoloAccess? = null
        @Volatile var pendingSendUntil = 0L
    }

    override fun onServiceConnected() {
        super.onServiceConnected()
        instance = this
    }

    override fun onUnbind(intent: Intent?): Boolean {
        instance = null
        return super.onUnbind(intent)
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        if (System.currentTimeMillis() > pendingSendUntil) return
        val root = rootInActiveWindow ?: return
        val pkg = root.packageName?.toString() ?: return
        if (!pkg.startsWith("com.whatsapp")) return
        val node = findSend(root) ?: return
        if (node.performAction(AccessibilityNodeInfo.ACTION_CLICK)) {
            pendingSendUntil = 0L
            AppLog.add("Mensagem enviada pelo WhatsApp")
        }
    }

    private fun findSend(root: AccessibilityNodeInfo): AccessibilityNodeInfo? {
        for (id in listOf("com.whatsapp:id/send", "com.whatsapp.w4b:id/send")) {
            val l = root.findAccessibilityNodeInfosByViewId(id)
            if (!l.isNullOrEmpty()) return l[0]
        }
        for (label in listOf("Enviar", "Send")) {
            val l = root.findAccessibilityNodeInfosByText(label)
            val hit = l?.firstOrNull {
                it.contentDescription?.toString().equals(label, true) || it.text?.toString().equals(label, true)
            }
            if (hit != null) return hit
        }
        return null
    }

    override fun onInterrupt() {}
}
