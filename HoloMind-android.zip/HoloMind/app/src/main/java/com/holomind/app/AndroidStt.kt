package com.holomind.app

import android.content.Context
import android.content.Intent
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import java.util.concurrent.CountDownLatch
import java.util.concurrent.TimeUnit

/**
 * Reconhecimento de voz do próprio Android (Google), preferindo o modo offline, com texto em tempo real.
 * O SpeechRecognizer tem de viver na thread principal; aqui bloqueamos a thread da escuta até haver resultado.
 */
object AndroidStt {
    private val main = Handler(Looper.getMainLooper())

    private class Res {
        @Volatile var text = ""
        @Volatile var partial = ""
        @Volatile var err = 0
    }

    /** Devolve o texto ouvido ("" = ninguém falou) ou null se este motor não pôde ser usado (cai para o Vosk). */
    fun listen(ctx: Context, waitMs: Long, onPartial: (String) -> Unit): String? {
        if (!SpeechRecognizer.isRecognitionAvailable(ctx)) {
            AppLog.add("Reconhecimento de voz do Android indisponível neste telemóvel")
            return null
        }
        var r = once(ctx, waitMs, onPartial, Build.VERSION.SDK_INT >= 33)
        // pacote de idioma do reconhecedor "no aparelho" em falta: tenta o reconhecedor normal em modo offline
        if (Build.VERSION.SDK_INT >= 33 && (r.err == 12 || r.err == 13)) r = once(ctx, waitMs, onPartial, false)
        if (r.err == 8) { // ocupado
            try { Thread.sleep(700) } catch (_: InterruptedException) { return "" }
            r = once(ctx, waitMs, onPartial, false)
        }
        return when (r.err) {
            0 -> r.text.ifBlank { r.partial }
            5, 6, 7, -2 -> r.partial          // cliente/sem fala/sem correspondência: nada percebido
            else -> {
                val hint = if (r.err == 1 || r.err == 2 || r.err == 4 || r.err == 12 || r.err == 13)
                    " (falta o pacote de português offline: Google › Definições › Voz › Reconhecimento de voz offline)" else ""
                AppLog.add("Reconhecimento do Android: erro ${r.err}$hint")
                null
            }
        }
    }

    private fun once(ctx: Context, waitMs: Long, onPartial: (String) -> Unit, onDevice: Boolean): Res {
        val res = Res()
        val done = CountDownLatch(1)
        var sr: SpeechRecognizer? = null
        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, "pt-PT")
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_PREFERENCE, "pt-PT")
            putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
            putExtra(RecognizerIntent.EXTRA_PREFER_OFFLINE, true)
            putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 1)
            putExtra(RecognizerIntent.EXTRA_CALLING_PACKAGE, ctx.packageName)
            // tolera pausas a meio da frase ("ler… mensagem")
            putExtra(RecognizerIntent.EXTRA_SPEECH_INPUT_COMPLETE_SILENCE_LENGTH_MILLIS, 1600L)
            putExtra(RecognizerIntent.EXTRA_SPEECH_INPUT_POSSIBLY_COMPLETE_SILENCE_LENGTH_MILLIS, 1600L)
        }
        main.post {
            try {
                val s = if (onDevice && Build.VERSION.SDK_INT >= 33 && SpeechRecognizer.isOnDeviceRecognitionAvailable(ctx))
                    SpeechRecognizer.createOnDeviceSpeechRecognizer(ctx)
                else SpeechRecognizer.createSpeechRecognizer(ctx)
                sr = s
                s.setRecognitionListener(object : RecognitionListener {
                    override fun onReadyForSpeech(params: Bundle?) {}
                    override fun onBeginningOfSpeech() {}
                    override fun onRmsChanged(rmsdB: Float) { ListenService.level = (rmsdB.coerceIn(0f, 10f) * 120).toInt() }
                    override fun onBufferReceived(buffer: ByteArray?) {}
                    override fun onEndOfSpeech() {}
                    override fun onError(error: Int) { res.err = error; done.countDown() }
                    override fun onResults(results: Bundle?) {
                        res.text = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull()?.trim() ?: ""
                        done.countDown()
                    }
                    override fun onPartialResults(partialResults: Bundle?) {
                        val p = partialResults?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull()?.trim() ?: ""
                        if (p.isNotBlank()) { res.partial = p; onPartial(p) }
                    }
                    override fun onEvent(eventType: Int, params: Bundle?) {}
                })
                s.startListening(intent)
            } catch (t: Throwable) {
                AppLog.add("Reconhecimento do Android: ${t.message ?: t.javaClass.simpleName}")
                res.err = -1
                done.countDown()
            }
        }
        try {
            if (!done.await(waitMs + 15000, TimeUnit.MILLISECONDS)) res.err = 5
        } catch (_: InterruptedException) {
            res.err = -2
        }
        val gone = CountDownLatch(1)
        main.post {
            try { sr?.cancel(); sr?.destroy() } catch (_: Throwable) {}
            gone.countDown()
        }
        try { gone.await(1500, TimeUnit.MILLISECONDS) } catch (_: InterruptedException) {}
        ListenService.level = 0
        return res
    }
}
