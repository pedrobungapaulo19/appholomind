package com.holomind.app

import android.app.PendingIntent
import android.content.Intent
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.service.quicksettings.Tile
import android.service.quicksettings.TileService
import androidx.core.content.ContextCompat

/** Botão rápido nas definições do Android para ligar/desligar o HoloMind. */
class HoloTile : TileService() {
    override fun onStartListening() { refresh() }

    override fun onClick() {
        val prefs = Prefs(this)
        if (ListenService.isRunning) {
            prefs.serviceEnabled = false
            stopService(Intent(this, ListenService::class.java))
        } else {
            prefs.serviceEnabled = true
            try {
                ContextCompat.startForegroundService(this, Intent(this, ListenService::class.java))
            } catch (e: Exception) {
                openApp()
            }
        }
        refresh()
        Handler(Looper.getMainLooper()).postDelayed({ refresh() }, 800)
    }

    private fun refresh() {
        val t = qsTile ?: return
        t.state = if (ListenService.isRunning) Tile.STATE_ACTIVE else Tile.STATE_INACTIVE
        t.label = "HoloMind"
        t.updateTile()
    }

    @Suppress("DEPRECATION")
    private fun openApp() {
        val i = Intent(this, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        if (Build.VERSION.SDK_INT >= 34) {
            startActivityAndCollapse(PendingIntent.getActivity(this, 5, i, PendingIntent.FLAG_IMMUTABLE))
        } else {
            startActivityAndCollapse(i)
        }
    }
}
