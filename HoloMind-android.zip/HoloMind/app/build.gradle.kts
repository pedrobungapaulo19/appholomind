import java.io.File
import java.net.URL
import java.util.zip.ZipInputStream

plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.holomind.app"
    compileSdk = 34

    defaultConfig {
        applicationId = "com.holomind.app"
        minSdk = 26
        targetSdk = 34
        versionCode = (System.getenv("GITHUB_RUN_NUMBER") ?: "1").toInt()
        versionName = "0.4.0"
        ndk { abiFilters += listOf("arm64-v8a", "armeabi-v7a", "x86_64") }
    }

    // Chave fixa: as atualizações instalam por cima sem desinstalar (mantenha o repositório PRIVADO)
    signingConfigs {
        create("holomind") {
            storeFile = file("holomind.jks")
            storePassword = "holomind2026"
            keyAlias = "holomind"
            keyPassword = "holomind2026"
        }
    }
    buildTypes {
        release {
            isMinifyEnabled = false
            signingConfig = signingConfigs.getByName("holomind")
        }
        debug { signingConfig = signingConfigs.getByName("holomind") }
    }
    lint {
        abortOnError = false
        checkReleaseBuilds = false
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions { jvmTarget = "17" }
}

dependencies {
    implementation("androidx.core:core-ktx:1.12.0")
    implementation("androidx.activity:activity-ktx:1.8.2")
    implementation("net.java.dev.jna:jna:5.13.0@aar")
    implementation("com.alphacephei:vosk-android:0.3.47")
    testImplementation("junit:junit:4.13.2")
}

// ---------------------------------------------------------------------------
// Modelo de voz embutido no APK: descarregado automaticamente no build (se ainda
// não estiver em src/main/assets/model-pt). Quem instala o APK não precisa de fazer nada.
// ---------------------------------------------------------------------------
val voskModelUrls = listOf(
    "https://alphacephei.com/vosk/models/vosk-model-small-pt-0.3.zip",
    "https://alphacephei.com/kaldi/models/vosk-model-small-pt-0.3.zip"
)

val downloadVoskModel by tasks.registering {
    val target = layout.projectDirectory.dir("src/main/assets/model-pt").asFile
    val tmpZip = layout.buildDirectory.file("vosk/model.zip").get().asFile
    onlyIf { !File(target, "conf").isDirectory }
    doLast {
        tmpZip.parentFile.mkdirs()
        var ok = false
        var last: Exception? = null
        loop@ for (url in voskModelUrls) {
            for (attempt in 1..3) {
                try {
                    URL(url).openStream().use { i -> tmpZip.outputStream().use { o -> i.copyTo(o) } }
                    ok = true
                    break@loop
                } catch (e: Exception) {
                    last = e
                    Thread.sleep(2000)
                }
            }
        }
        if (!ok) throw GradleException("Não foi possível baixar o modelo de voz: ${last?.message}")

        val roots = setOf("am", "conf", "graph", "ivector", "rnnlm")
        target.deleteRecursively()
        target.mkdirs()
        val base = target.canonicalPath + File.separator
        ZipInputStream(tmpZip.inputStream().buffered()).use { z ->
            while (true) {
                val e = z.nextEntry ?: break
                val parts = e.name.split("/").filter { it.isNotEmpty() }
                if (parts.isEmpty()) continue
                if (parts.size == 1 && e.isDirectory && parts[0] !in roots) continue
                val rel = if (parts.size >= 2 && parts[0] !in roots) parts.drop(1) else parts
                val out = File(target, rel.joinToString("/"))
                if (!out.canonicalPath.startsWith(base)) continue
                if (e.isDirectory) out.mkdirs() else {
                    out.parentFile.mkdirs()
                    out.outputStream().use { z.copyTo(it) }
                }
            }
        }
        if (!File(target, "conf").isDirectory || !File(target, "am").isDirectory) {
            throw GradleException("Modelo de voz inválido após descompactar")
        }
    }
}

tasks.configureEach {
    if (name == "preBuild" || (name.startsWith("merge") && name.endsWith("Assets"))) {
        dependsOn(downloadVoskModel)
    }
}
