import java.io.File
import java.net.HttpURLConnection
import java.net.URL
import java.util.zip.ZipInputStream

plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.holomind.app"
    compileSdk = 34

    defaultConfig {
        applicationId = "com.holomind.app"
        minSdk = 26
        targetSdk = 34
        versionCode = (System.getenv("GITHUB_RUN_NUMBER") ?: "1").toInt()
        versionName = "0.4.0"
        ndk { abiFilters += listOf("arm64-v8a", "armeabi-v7a", "x86_64") }
    }

    // Chave fixa: as atualizações instalam por cima sem desinstalar (mantenha o repositório PRIVADO)
    signingConfigs {
        create("holomind") {
            storeFile = file("holomind.jks")
            storePassword = "holomind2026"
            keyAlias = "holomind"
            keyPassword = "holomind2026"
        }
    }
    buildTypes {
        release {
            isMinifyEnabled = false
            signingConfig = signingConfigs.getByName("holomind")
        }
        debug { signingConfig = signingConfigs.getByName("holomind") }
    }
    lint {
        abortOnError = false
        checkReleaseBuilds = false
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions { jvmTarget = "17" }
}

dependencies {
    implementation("androidx.core:core-ktx:1.12.0")
    implementation("androidx.activity:activity-ktx:1.8.2")
    implementation("net.java.dev.jna:jna:5.13.0@aar")
    implementation("com.alphacephei:vosk-android:0.3.47")
    testImplementation("junit:junit:4.13.2")
}

// ---------------------------------------------------------------------------
// Modelo de voz embutido no APK: descarregado automaticamente no build (se ainda
// não estiver em src/main/assets/model-pt). Quem instala o APK não precisa de fazer nada.
// ---------------------------------------------------------------------------
// O modelo pt-0.3 usa o formato "plano" (final.mdl, Gr.fst, HCLr.fst, ivector/...). Outros modelos usam am/ + conf/.
fun isVoskModelDir(d: File): Boolean =
    File(d, "final.mdl").exists() || (File(d, "am/final.mdl").exists() && File(d, "conf/model.conf").exists())

val voskModelUrls = listOf(
    "https://alphacephei.com/vosk/models/vosk-model-small-pt-0.3.zip",
    "https://huggingface.co/rhasspy/vosk-models/resolve/main/pt/vosk-model-small-pt-0.3.zip",
    "https://huggingface.co/localstack/vosk-models/resolve/main/vosk-model-small-pt-0.3.zip"
)

val downloadVoskModel by tasks.registering {
    val target = layout.projectDirectory.dir("src/main/assets/model-pt").asFile
    val tmpZip = layout.buildDirectory.file("vosk/model.zip").get().asFile
    onlyIf { !isVoskModelDir(target) }
    doLast {
        val roots = setOf("am", "conf", "graph", "ivector", "rnnlm")
        val problems = mutableListOf<String>()

        // Tenta uma origem: descarrega, confirma que é mesmo um zip do modelo e descompacta.
        fun tryDownload(url: String): Boolean {
            try {
                tmpZip.parentFile.mkdirs()
                tmpZip.delete()
                val c = URL(url).openConnection() as HttpURLConnection
                c.connectTimeout = 30000
                c.readTimeout = 120000
                c.instanceFollowRedirects = true
                c.setRequestProperty("User-Agent", "Mozilla/5.0 (HoloMind build)")
                val code = c.responseCode
                if (code !in 200..299) {
                    problems.add("$url -> HTTP $code")
                    return false
                }
                c.inputStream.use { i -> tmpZip.outputStream().use { o -> i.copyTo(o) } }
                val size = tmpZip.length()
                val head = tmpZip.inputStream().use { st -> ByteArray(4).also { st.read(it) } }
                val isZip = head[0] == 0x50.toByte() && head[1] == 0x4B.toByte()
                if (size < 20000000L || !isZip) {
                    problems.add("$url -> ficheiro inválido ($size bytes, tipo ${c.contentType})")
                    return false
                }
                target.deleteRecursively()
                target.mkdirs()
                val base = target.canonicalPath + File.separator
                ZipInputStream(tmpZip.inputStream().buffered()).use { z ->
                    while (true) {
                        val e = z.nextEntry ?: break
                        val parts = e.name.split("/").filter { it.isNotEmpty() }
                        if (parts.isEmpty()) continue
                        if (parts.size == 1 && e.isDirectory && parts[0] !in roots) continue
                        val rel = if (parts.size >= 2 && parts[0] !in roots) parts.drop(1) else parts
                        val out = File(target, rel.joinToString("/"))
                        if (!out.canonicalPath.startsWith(base)) continue
                        if (e.isDirectory) out.mkdirs() else {
                            out.parentFile.mkdirs()
                            out.outputStream().use { z.copyTo(it) }
                        }
                    }
                }
                if (!isVoskModelDir(target)) {
                    problems.add("$url -> zip sem final.mdl (conteúdo: ${target.list()?.joinToString()})")
                    target.deleteRecursively()
                    return false
                }
                return true
            } catch (e: Exception) {
                problems.add("$url -> ${e.javaClass.simpleName}: ${e.message}")
                return false
            }
        }

        if (voskModelUrls.none { tryDownload(it) }) {
            target.deleteRecursively()
            throw GradleException("Não foi possível obter o modelo de voz:\n" + problems.joinToString("\n"))
        }
        println("Modelo de voz instalado em $target")
    }
}

tasks.configureEach {
    if (name == "preBuild" || (name.startsWith("merge") && name.endsWith("Assets"))) {
        dependsOn(downloadVoskModel)
    }
}
