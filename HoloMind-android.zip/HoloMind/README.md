# HoloMind (Android) — v0.2

Assistente de voz offline que fica em segundo plano à escuta de "HoloMind".

## O que já faz
- Serviço em primeiro plano (microfone) com notificação fixa.
- Deteta "HoloMind" offline (Vosk) e responde "Estou à escuta".
- Comandos: "responder" (pergunta a quem, o texto, pede confirmação e envia pela resposta rápida da notificação), "ler mensagens" (lê notificações de WhatsApp/SMS/Telegram…), "ligar para X" (procura nos contactos e liga), "que horas são".
- Ecrã de configuração (HTML/JS) com guardar automático: nome, palavras de ativação, sensibilidade (com medidor de volume em tempo real), modo ECO, escuta fiável com ecrã apagado, horário de silêncio, bateria mínima.
- Lista de preparação (permissões com explicação), diagnóstico dentro da app (o que o microfone ouviu) e botões "Testar voz" e "Copiar registo" — não precisa de computador nem de adb.
- Botão "Parar" na notificação. A configuração aplica-se na hora, sem reiniciar.
- Dorme também durante chamadas (incluindo WhatsApp). Reconhecimento da palavra tolera 1–2 letras trocadas.

## Poupança de bateria
1. VAD por energia: o reconhecedor só corre quando há som acima do limiar (sensibilidade).
2. "Dorme" (fecha o microfone) em horário de silêncio, com bateria baixa (e não a carregar) e durante chamadas.
3. Modo ECO: pausas curtas no microfone durante o silêncio (pode falhar uma palavra ocasional).

## Passo a passo
1. Instale o **Android Studio** (grátis) — https://developer.android.com/studio
2. Descarregue o modelo **vosk-model-small-pt-0.3** — https://alphacephei.com/vosk/models
3. Descompacte. Dentro há as pastas `am`, `conf`, `graph`, `ivector`.
   Copie o CONTEÚDO para `app/src/main/assets/model-pt/` (a pasta `conf` deve ficar em `model-pt/conf`).
4. Android Studio → File → Open → escolha a pasta HoloMind. Aguarde o "Gradle Sync" (precisa de internet na 1.ª vez).
5. No telemóvel: Definições → Sobre → toque 7× em "Número da versão" → Opções de programador → ative **Depuração USB**.
6. Ligue o cabo, aceite o aviso no telemóvel, clique ▶ Run no Android Studio.
7. Na app: toque "Ativar" em cada permissão, depois "Ligar HoloMind".
   - "Ler notificações" abre uma lista: ative o HoloMind.
   - "Sem restrição de bateria": aceite (essencial em Xiaomi/Tecno/Infinix/Samsung).
8. Teste: diga "HoloMind" → ouve "Estou à escuta" → diga "ler mensagens" ou "ligar para <nome>".

## Ver permissões e depurar
- Dentro da app: secção "Diagnóstico" mostra `Ouvi: “...”`. Se não ativar, veja como ele escreveu "HoloMind" e adicione essa variante em "Palavras de ativação". (Com computador: `adb logcat -s HoloMind`.)
- Permissões: `adb shell dumpsys package com.holomind.app | grep -E "permission|granted"`
- Bateria: `adb shell dumpsys batterystats --reset` … use um dia … `adb shell dumpsys batterystats com.holomind.app`
- Serviço ativo: `adb shell dumpsys activity services com.holomind.app`
- Gerar APK: Build → Build APK(s) → app/build/outputs/apk/debug/app-debug.apk

## Limitações do Android (não são bugs)
- Não é possível digitar o PIN/senha do ecrã de bloqueio por app. Por isso o HoloMind não guarda PIN.
- Android 14+: o serviço de microfone não inicia sozinho no boot. Após reiniciar, aparece uma notificação "toque para reativar".
- Abrir outros apps a partir do segundo plano é bloqueado (Android 10+). Ligar funciona (TelecomManager). Controlar outros apps virá com AccessibilityService.
- "HoloMind" não é palavra do vocabulário; o modelo pode ouvir variantes. Mais tarde dá para trocar por openWakeWord com palavra treinada.

## Próximos passos
1. AccessibilityService para controlar outros apps.
2. Wake word dedicada (openWakeWord/TFLite) para menos consumo.
3. Interpretar comandos com modelo pequeno offline.

## Sem computador? Compilar pelo GitHub (só com o telemóvel)
Veja o ficheiro `build.yml` e as instruções no chat: o GitHub compila o APK na nuvem e publica-o em "Releases".

## Testes automáticos
`gradle testDebugUnitTest` corre os testes em `app/src/test` (reconhecimento da palavra de ativação). O workflow do GitHub já os executa; se falharem, o APK é gerado na mesma.
