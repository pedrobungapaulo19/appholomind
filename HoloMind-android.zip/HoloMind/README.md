# HoloMind (Android) — v0.3

Assistente de voz offline que fica em segundo plano à escuta de "HoloMind".

## O que já faz
- Serviço em primeiro plano (microfone) com notificação fixa.
- Deteta "HoloMind" offline (Vosk) e responde "Estou à escuta".
- Comandos: "responder" (pergunta a quem, o texto, pede confirmação e envia pela resposta rápida da notificação), "ler mensagens" (lê notificações de WhatsApp/SMS/Telegram…), "ligar para X" (procura nos contactos e liga), "que horas são".
- Ecrã de configuração (HTML/JS) com guardar automático: nome, palavras de ativação, sensibilidade (com medidor de volume em tempo real), modo ECO, escuta fiável com ecrã apagado, horário de silêncio, bateria mínima.
- Lista de preparação (permissões com explicação), diagnóstico dentro da app (o que o microfone ouviu) e botões "Testar voz" e "Copiar registo" — não precisa de computador nem de adb.
- Botão "Parar" na notificação. A configuração aplica-se na hora, sem reiniciar.
- Dorme também durante chamadas (incluindo WhatsApp). Reconhecimento da palavra tolera 1–2 letras trocadas.

## Poupança de bateria
1. VAD por energia: o reconhecedor só corre quando há som acima do limiar (sensibilidade).
2. "Dorme" (fecha o microfone) em horário de silêncio, com bateria baixa (e não a carregar) e durante chamadas.
3. Modo ECO: pausas curtas no microfone durante o silêncio (pode falhar uma palavra ocasional).

## Passo a passo
1. Instale o **Android Studio** (grátis) — https://developer.android.com/studio
2. Descarregue o modelo **vosk-model-small-pt-0.3** — https://alphacephei.com/vosk/models
3. (Opcional) O build descarrega e embute o modelo sozinho (tarefa `downloadVoskModel` em `app/build.gradle.kts`). Só precisa de copiar à mão para `app/src/main/assets/model-pt/` se compilar sem internet.
4. Android Studio → File → Open → escolha a pasta HoloMind. Aguarde o "Gradle Sync" (precisa de internet na 1.ª vez).
5. No telemóvel: Definições → Sobre → toque 7× em "Número da versão" → Opções de programador → ative **Depuração USB**.
6. Ligue o cabo, aceite o aviso no telemóvel, clique ▶ Run no Android Studio.
7. Na app: toque "Ativar" em cada permissão, depois "Ligar HoloMind".
   - "Ler notificações" abre uma lista: ative o HoloMind.
   - "Sem restrição de bateria": aceite (essencial em Xiaomi/Tecno/Infinix/Samsung).
8. Teste: diga "HoloMind" → ouve "Estou à escuta" → diga "ler mensagens" ou "ligar para <nome>".

## Ver permissões e depurar
- Dentro da app: secção "Diagnóstico" mostra `Ouvi: “...”`. Se não ativar, veja como ele escreveu "HoloMind" e adicione essa variante em "Palavras de ativação". (Com computador: `adb logcat -s HoloMind`.)
- Permissões: `adb shell dumpsys package com.holomind.app | grep -E "permission|granted"`
- Bateria: `adb shell dumpsys batterystats --reset` … use um dia … `adb shell dumpsys batterystats com.holomind.app`
- Serviço ativo: `adb shell dumpsys activity services com.holomind.app`
- Gerar APK: Build → Build APK(s) → app/build/outputs/apk/debug/app-debug.apk

## Ligar sozinho após reiniciar
O HoloMind tenta arrancar sozinho no arranque do telemóvel (e depois de cada atualização). Para o Android permitir:
1. Na app, ative **"Ligar sozinho após reiniciar"** (permissão "Aparecer por cima de outros apps"). Não desenha nada no ecrã; é a isenção que o Android aceita para iniciar o microfone em segundo plano.
2. Ative **"Sem restrição de bateria"**.
3. Xiaomi/Redmi/Poco, Tecno/Infinix/itel, Oppo/Realme, Vivo, Samsung: nas definições do app ative **Início automático** e, no Samsung, retire o app de "Apps em suspensão".
4. Deixe "Ler notificações" ativo: o Android liga esse serviço sozinho no arranque e o HoloMind aproveita para reativar a escuta.
Se o Android recusar, aparece a notificação "Toque para reativar". Não há garantia em 100% dos telemóveis; o registo na secção Diagnóstico diz o que aconteceu ("Escuta iniciada após arranque" ou "Arranque automático recusado").

## Instalar com o Google Play Protect
- Aviso "Aplicação não verificada / bloqueada": toque em **Mais detalhes → Instalar mesmo assim**. Se aparecer "Analisar app", escolha analisar: depois de analisado, instala normalmente.
- Se o navegador bloquear: permita "Instalar apps desconhecidas" para o navegador ou para o gestor de ficheiros.
- Se não deixar mesmo: Play Store → perfil → Play Protect → ⚙ → desligue "Analisar apps com o Play Protect", instale e volte a ligar.
- **Definições restritas (Android 13+)**: se "Ler notificações" ou "Aparecer por cima" estiverem a cinzento, vá a Definições → Apps → HoloMind → ⋮ (três pontos) → **Permitir definições restritas** e tente de novo.
- Atualizações: o APK vem assinado com uma chave fixa. Se tiver uma versão antiga (v0.1/v0.2) instalada, desinstale-a uma única vez; depois as atualizações instalam por cima.
- Mantenha o repositório do GitHub **privado** (a chave de assinatura está no projeto).

## Limitações do Android (não são bugs)
- Não é possível digitar o PIN/senha do ecrã de bloqueio por app. Por isso o HoloMind não guarda PIN.
- Arranque automático após reiniciar depende do fabricante e da versão do Android (ver secção acima).
- Abrir outros apps a partir do segundo plano é bloqueado (Android 10+). Ligar funciona (TelecomManager). Controlar outros apps virá com AccessibilityService.
- "HoloMind" não é palavra do vocabulário; o modelo pode ouvir variantes. Mais tarde dá para trocar por openWakeWord com palavra treinada.

## Próximos passos
1. AccessibilityService para controlar outros apps.
2. Wake word dedicada (openWakeWord/TFLite) para menos consumo.
3. Interpretar comandos com modelo pequeno offline.

## Sem computador? Compilar pelo GitHub (só com o telemóvel)
Veja o ficheiro `build.yml` e as instruções no chat: o GitHub compila o APK na nuvem e publica-o em "Releases".

## Testes automáticos
`gradle testDebugUnitTest` corre os testes em `app/src/test` (reconhecimento da palavra de ativação). O workflow do GitHub já os executa; se falharem, o APK é gerado na mesma.

## Modelo de voz já dentro do APK
O build (GitHub ou Android Studio) descarrega o modelo `vosk-model-small-pt-0.3` e embute-o no APK. Os utilizadores finais só instalam e usam; o botão "Importar modelo" na app é apenas um plano B. O workflow falha de forma visível se o APK sair sem o modelo.
