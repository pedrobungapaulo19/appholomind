# HoloMind (Android) — v0.6

Assistente de voz offline que fica em segundo plano à escuta de "HoloMind".

## O que já faz
- Serviço em primeiro plano (microfone) com notificação fixa.
- Deteta "HoloMind" offline (Vosk) e responde "Estou à escuta".
- Comandos: "responder" (pergunta a quem, o texto, pede confirmação e envia pela resposta rápida da notificação), "ler mensagens" (lê notificações de WhatsApp/SMS/Telegram…), "ligar para X" (procura nos contactos e liga), "que horas são".
- Ecrã de configuração (HTML/JS) com guardar automático: nome, palavras de ativação, sensibilidade (com medidor de volume em tempo real), modo ECO, escuta fiável com ecrã apagado, horário de silêncio, bateria mínima.
- Lista de preparação (permissões com explicação), diagnóstico dentro da app (o que o microfone ouviu) e botões "Testar voz" e "Copiar registo" — não precisa de computador nem de adb.
- Botão "Parar" na notificação. A configuração aplica-se na hora, sem reiniciar.
- Dorme também durante chamadas (incluindo WhatsApp). Reconhecimento da palavra tolera 1–2 letras trocadas.

## Novidades v0.6
- **Primeiro uso guiado:** permissões uma a uma; o HoloMind pergunta por voz (e mostra no ecrã) "Como pretende que eu lhe chame?", mostra o nome que ouviu para confirmar/corrigir; depois pergunta como quer chamá-lo (HoloMaind, HoloMind ou Holo) e ensina-se a voz.
- **Inglês:** modelo inglês embutido (`vosk-model-small-en-us-0.15`). A palavra de ativação é ouvida também em inglês ("hollow mind") com gramática restrita, e os pedidos aceitam inglês ("open WhatsApp", "call John", "read my messages"). As mensagens em inglês são lidas com voz inglesa.
- **Abrir apps e enviar mensagens:** "abrir o WhatsApp/Facebook…", "mandar mensagem ao João dizendo …" (WhatsApp, com o serviço de acessibilidade ligado, ou SMS). Facebook/Messenger: só abre a app.
- **Memória que aprende (offline):** apelidos de contactos, frases novas, contactos prioritários, horas de uso (sugere horário de silêncio), notas e lembretes ("lembra-me de … daqui a dez minutos"), "bom dia", próxima mensagem, "responde-lhe". Ecrã "O que aprendi" e botão "Esquecer tudo".
- **Modo condução**, botão rápido (Quick Settings), velocidade e tom da voz.
- **Correção:** "Ensinar a minha voz" já não aprende palavras comuns como "olá" ou "mãe".
- O classificador de IA fica para mais tarde.
Notas: o Android 15+ só deixa abrir apps em segundo plano com a permissão "Aparecer por cima" ativa (o app põe uma âncora de 1 pixel); se bloquear, aparece uma notificação para tocar.

## Novidades v0.7
- **Pedidos flexíveis e encadeados** (`Nlu.kt`, offline): "contactos", "entra nos contactos", "abre contacto" abrem os contactos; "entra nos contactos e liga para o fulano" faz as duas coisas; "verifica as mensagens", "entra na mensagem do X", "responde ao X dizendo …", "hora", "me diz que horas são". Tolera palavras a mais e erros pequenos do reconhecedor.
- **Palavra de ativação + pedido na mesma frase:** "olo, que horas são" já responde logo, sem esperar pelo "estou à escuta".
- **Barra de notificações:** lê também as mensagens que já lá estavam antes de o HoloMind ligar.
- **Menos falsos reconhecimentos:** o microfone só acorda o reconhecedor com som contínuo (não com estalidos) e o limiar adapta-se melhor ao ruído.
- **"Ensinar a minha voz" corrigido:** cada frase ouvida conta (mesmo que só o reconhecedor inglês a perceba), ignora palavras comuns ("olá", "mãe") e diz o que fez com cada tentativa.

## Se o HoloMind não responde quando digo "HoloMind"
"HoloMind" lê-se **olomaind** em português e o reconhecedor escreve-o de várias formas ("olo mente", "olho mente"…).
1. Ligue o HoloMind e diga a palavra: a linha **Ouvi: “…”** por cima do medidor mostra o que ele percebeu.
2. Toque em **Ensinar a minha voz** e diga "HoloMind" 3 vezes: o app guarda como a sua voz é percebida.
3. O medidor de volume deve passar a linha laranja quando fala. O limiar adapta-se ao ruído do ambiente.
4. Depois de ativar, o HoloMind continua a ouvir pedidos durante uns segundos, sem repetir "HoloMind".
Novos pedidos: "ligar a lanterna", "apagar a lanterna", "qual a bateria", "aumentar/baixar o volume".

## Poupança de bateria
1. VAD por energia: o reconhecedor só corre quando há som acima do limiar (sensibilidade).
2. "Dorme" (fecha o microfone) em horário de silêncio, com bateria baixa (e não a carregar) e durante chamadas.
3. Modo ECO: pausas curtas no microfone durante o silêncio (pode falhar uma palavra ocasional).

## Passo a passo
1. Instale o **Android Studio** (grátis) — https://developer.android.com/studio
2. Descarregue o modelo **vosk-model-small-pt-0.3** — https://alphacephei.com/vosk/models
3. (Opcional) O build descarrega e embute o modelo sozinho (tarefa `downloadVoskModel` em `app/build.gradle.kts`). Só precisa de copiar à mão para `app/src/main/assets/model-pt/` se compilar sem internet.
4. Android Studio → File → Open → escolha a pasta HoloMind. Aguarde o "Gradle Sync" (precisa de internet na 1.ª vez).
5. No telemóvel: Definições → Sobre → toque 7× em "Número da versão" → Opções de programador → ative **Depuração USB**.
6. Ligue o cabo, aceite o aviso no telemóvel, clique ▶ Run no Android Studio.
7. Na app: toque "Ativar" em cada permissão, depois "Ligar HoloMind".
   - "Ler notificações" abre uma lista: ative o HoloMind.
   - "Sem restrição de bateria": aceite (essencial em Xiaomi/Tecno/Infinix/Samsung).
8. Teste: diga "HoloMind" → ouve "Estou à escuta" → diga "ler mensagens" ou "ligar para <nome>".

## Ver permissões e depurar
- Dentro da app: secção "Diagnóstico" mostra `Ouvi: “...”`. Se não ativar, veja como ele escreveu "HoloMind" e adicione essa variante em "Palavras de ativação". (Com computador: `adb logcat -s HoloMind`.)
- Permissões: `adb shell dumpsys package com.holomind.app | grep -E "permission|granted"`
- Bateria: `adb shell dumpsys batterystats --reset` … use um dia … `adb shell dumpsys batterystats com.holomind.app`
- Serviço ativo: `adb shell dumpsys activity services com.holomind.app`
- Gerar APK: Build → Build APK(s) → app/build/outputs/apk/debug/app-debug.apk

## Ligar sozinho após reiniciar
O HoloMind tenta arrancar sozinho no arranque do telemóvel (e depois de cada atualização). Para o Android permitir:
1. Na app, ative **"Ligar sozinho após reiniciar"** (permissão "Aparecer por cima de outros apps"). Não desenha nada no ecrã; é a isenção que o Android aceita para iniciar o microfone em segundo plano.
2. Ative **"Sem restrição de bateria"**.
3. Xiaomi/Redmi/Poco, Tecno/Infinix/itel, Oppo/Realme, Vivo, Samsung: nas definições do app ative **Início automático** e, no Samsung, retire o app de "Apps em suspensão".
4. Deixe "Ler notificações" ativo: o Android liga esse serviço sozinho no arranque e o HoloMind aproveita para reativar a escuta.
Se o Android recusar, aparece a notificação "Toque para reativar". Não há garantia em 100% dos telemóveis; o registo na secção Diagnóstico diz o que aconteceu ("Escuta iniciada após arranque" ou "Arranque automático recusado").

## Instalar com o Google Play Protect
- Aviso "Aplicação não verificada / bloqueada": toque em **Mais detalhes → Instalar mesmo assim**. Se aparecer "Analisar app", escolha analisar: depois de analisado, instala normalmente.
- Se o navegador bloquear: permita "Instalar apps desconhecidas" para o navegador ou para o gestor de ficheiros.
- Se não deixar mesmo: Play Store → perfil → Play Protect → ⚙ → desligue "Analisar apps com o Play Protect", instale e volte a ligar.
- **Definições restritas (Android 13+)**: se "Ler notificações" ou "Aparecer por cima" estiverem a cinzento, vá a Definições → Apps → HoloMind → ⋮ (três pontos) → **Permitir definições restritas** e tente de novo.
- Atualizações: o APK vem assinado com uma chave fixa. Se tiver uma versão antiga (v0.1/v0.2) instalada, desinstale-a uma única vez; depois as atualizações instalam por cima.
- Mantenha o repositório do GitHub **privado** (a chave de assinatura está no projeto).

## Limitações do Android (não são bugs)
- Não é possível digitar o PIN/senha do ecrã de bloqueio por app. Por isso o HoloMind não guarda PIN.
- Arranque automático após reiniciar depende do fabricante e da versão do Android (ver secção acima).
- Abrir outros apps a partir do segundo plano é bloqueado (Android 10+). Ligar funciona (TelecomManager). Controlar outros apps virá com AccessibilityService.
- "HoloMind" não é palavra do vocabulário; o modelo pode ouvir variantes. Mais tarde dá para trocar por openWakeWord com palavra treinada.

## Próximos passos
1. AccessibilityService para controlar outros apps.
2. Wake word dedicada (openWakeWord/TFLite) para menos consumo.
3. Interpretar comandos com modelo pequeno offline.

## Sem computador? Compilar pelo GitHub (só com o telemóvel)
Veja o ficheiro `build.yml` e as instruções no chat: o GitHub compila o APK na nuvem e publica-o em "Releases".

## Testes automáticos
`gradle testDebugUnitTest` corre os testes em `app/src/test` (reconhecimento da palavra de ativação). O workflow do GitHub já os executa; se falharem, o APK é gerado na mesma.

## Modelo de voz já dentro do APK
O build (GitHub ou Android Studio) descarrega o modelo `vosk-model-small-pt-0.3` e embute-o no APK. Os utilizadores finais só instalam e usam; o botão "Importar modelo" na app é apenas um plano B. O workflow falha de forma visível se o APK sair sem o modelo.

## v0.7.1 — correções de reconhecimento
- O reconhecedor inglês já não gera "pedidos" soltos ("the", "all", "nice"): só conta se for um comando conhecido.
- Janela de pedidos com gramática portuguesa (frases de comando) como rede de segurança quando o texto livre falha.
- Depois da palavra de ativação toca um "bip" curto em vez de falar "Estou à escuta" (ativa mais depressa).
- Na conversa seguida, ruído/silêncio é ignorado em vez de virar pedido.
- Buffer do microfone maior (evita perder áudio) e o registo mostra o que cada reconhecedor ouviu: "Ouvi PT / gramática / EN".

## v0.7.2
- Corrigido o "Erro: null" ao desligar (era a thread a ser interrompida, não um erro).
- Escuta com pausas: espera até 6 s pelo início da fala e tolera pausas de ~1,6 s ("ler… mensagem"); o texto aparece em tempo real (linha "Ouvi").
- "Entra nas mensagens" abre a app de mensagens (a da última mensagem, senão WhatsApp) e pergunta "Qual é o próximo passo?". Pedidos encadeados: "entra nas mensagens e lê a mensagem do fulano".
- Nomes incompletos ou mal ouvidos ("joa", "mariano") encontram o remetente/contacto mais parecido.
- "Abre as notificações / o status das notificações": abre a barra (se o Android deixar) e lê as mensagens.
- Workflow atualizado (checkout v6, setup-java v5, setup-gradle v6, upload-artifact v7): remove os avisos de Node 20.

## v0.8.0 — reconhecimento de voz do Android
- Os pedidos (depois da palavra de ativação) são ouvidos pelo reconhecimento de voz do Android, em modo offline quando possível, com texto em tempo real. O Vosk continua só na palavra de ativação e como plano B.
- Precisa do pacote de português offline: Google › Definições › Voz › Reconhecimento de voz offline › Português.
- Se o Android falhar duas vezes seguidas, o app volta ao Vosk até reiniciar (registo: "Reconhecimento do Android: erro N").
